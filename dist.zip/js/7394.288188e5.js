/*!
 * vue-admin-better
 * GitHub: https://github.com/zxwk1998/vue-admin-better
 * Gitee: https://gitee.com/chu1204505056/vue-admin-better
 *
 * 版权所有 (c) 2025 vue-admin-better
 * 本项目使用 MIT 许可证
 * 构建时间: 2026-11-11 04:09:41
 */
(self["rspackChunkvue_admin_better"] = self["rspackChunkvue_admin_better"] || []).push([[7394], {
46057: (function (module, __unused_rspack_exports, __webpack_require__) {
/**
 * @description 3个子配置，通用配置|主题配置|网络配置
 */
//默认配置
const {
  setting,
  theme,
  network
} = __webpack_require__(53114);
module.exports = Object.assign({}, setting, theme, network);

}),

}]);