/*!
 * vue-admin-better
 * GitHub: https://github.com/zxwk1998/vue-admin-better
 * Gitee: https://gitee.com/chu1204505056/vue-admin-better
 *
 * 版权所有 (c) 2025 vue-admin-better
 * 本项目使用 MIT 许可证
 * 构建时间: 2026-11-11 04:09:41
 */
"use strict";
(self["rspackChunkvue_admin_better"] = self["rspackChunkvue_admin_better"] || []).push([[8055], {
37514: (function (__unused_rspack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
/* import */ var echarts__rspack_import_0 = __webpack_require__(77129);
/* import */ var vue_echarts__rspack_import_1 = __webpack_require__(86667);


/* export default */ __webpack_exports__["default"] = (vue_echarts__rspack_import_1["default"]);

}),

}]);