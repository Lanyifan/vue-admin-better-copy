/*!
 * vue-admin-better
 * GitHub: https://github.com/zxwk1998/vue-admin-better
 * Gitee: https://gitee.com/chu1204505056/vue-admin-better
 *
 * 版权所有 (c) 2025 vue-admin-better
 * 本项目使用 MIT 许可证
 * 构建时间: 2026-11-11 04:09:41
 */
"use strict";
(self["rspackChunkvue_admin_better"] = self["rspackChunkvue_admin_better"] || []).push([[8226], {
23619: (function (__unused_rspack___webpack_module__, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
/* import */ var zrender_lib_core_util_js__rspack_import_1 = __webpack_require__(75275);
/* import */ var _util_model_js__rspack_import_0 = __webpack_require__(53781);
/* import */ var _Source_js__rspack_import_2 = __webpack_require__(17043);

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/


/**
 * AUTO-GENERATED FILE. DO NOT MODIFY.
 */

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/



var inner = (0,_util_model_js__rspack_import_0.makeInner)();
var dimTypeShort = {
  float: 'f',
  int: 'i',
  ordinal: 'o',
  number: 'n',
  time: 't'
};
/**
 * Represents the dimension requirement of a series.
 *
 * NOTICE:
 * When there are too many dimensions in dataset and many series, only the used dimensions
 * (i.e., used by coord sys and declared in `series.encode`) are add to `dimensionDefineList`.
 * But users may query data by other unused dimension names.
 * In this case, users can only query data if and only if they have defined dimension names
 * via ec option, so we provide `getDimensionIndexFromSource`, which only query them from
 * `source` dimensions.
 */
var SeriesDataSchema = /** @class */function () {
  function SeriesDataSchema(opt) {
    this.dimensions = opt.dimensions;
    this._dimOmitted = opt.dimensionOmitted;
    this.source = opt.source;
    this._fullDimCount = opt.fullDimensionCount;
    this._updateDimOmitted(opt.dimensionOmitted);
  }
  SeriesDataSchema.prototype.isDimensionOmitted = function () {
    return this._dimOmitted;
  };
  SeriesDataSchema.prototype._updateDimOmitted = function (dimensionOmitted) {
    this._dimOmitted = dimensionOmitted;
    if (!dimensionOmitted) {
      return;
    }
    if (!this._dimNameMap) {
      this._dimNameMap = ensureSourceDimNameMap(this.source);
    }
  };
  /**
   * @caution Can only be used when `dimensionOmitted: true`.
   *
   * Get index by user defined dimension name (i.e., not internal generate name).
   * That is, get index from `dimensionsDefine`.
   * If no `dimensionsDefine`, or no name get, return -1.
   */
  SeriesDataSchema.prototype.getSourceDimensionIndex = function (dimName) {
    return (0,zrender_lib_core_util_js__rspack_import_1.retrieve2)(this._dimNameMap.get(dimName), -1);
  };
  /**
   * @caution Can only be used when `dimensionOmitted: true`.
   *
   * Notice: may return `null`/`undefined` if user not specify dimension names.
   */
  SeriesDataSchema.prototype.getSourceDimension = function (dimIndex) {
    var dimensionsDefine = this.source.dimensionsDefine;
    if (dimensionsDefine) {
      return dimensionsDefine[dimIndex];
    }
  };
  SeriesDataSchema.prototype.makeStoreSchema = function () {
    var dimCount = this._fullDimCount;
    var willRetrieveDataByName = (0,_Source_js__rspack_import_2.shouldRetrieveDataByName)(this.source);
    var makeHashStrict = !shouldOmitUnusedDimensions(dimCount);
    // If source don't have dimensions or series don't omit unsed dimensions.
    // Generate from seriesDimList directly
    var dimHash = '';
    var dims = [];
    for (var fullDimIdx = 0, seriesDimIdx = 0; fullDimIdx < dimCount; fullDimIdx++) {
      var property = void 0;
      var type = void 0;
      var ordinalMeta = void 0;
      var seriesDimDef = this.dimensions[seriesDimIdx];
      // The list has been sorted by `storeDimIndex` asc.
      if (seriesDimDef && seriesDimDef.storeDimIndex === fullDimIdx) {
        property = willRetrieveDataByName ? seriesDimDef.name : null;
        type = seriesDimDef.type;
        ordinalMeta = seriesDimDef.ordinalMeta;
        seriesDimIdx++;
      } else {
        var sourceDimDef = this.getSourceDimension(fullDimIdx);
        if (sourceDimDef) {
          property = willRetrieveDataByName ? sourceDimDef.name : null;
          type = sourceDimDef.type;
        }
      }
      dims.push({
        property: property,
        type: type,
        ordinalMeta: ordinalMeta
      });
      // If retrieving data by index,
      //   use <index, type, ordinalMeta> to determine whether data can be shared.
      //   (Because in this case there might be no dimension name defined in dataset, but indices always exists).
      //   (Indices are always 0, 1, 2, ..., so we can ignore them to shorten the hash).
      // Otherwise if retrieving data by property name (like `data: [{aa: 123, bb: 765}, ...]`),
      //   use <property, type, ordinalMeta> in hash.
      if (willRetrieveDataByName && property != null
      // For data stack, we have make sure each series has its own dim on this store.
      // So we do not add property to hash to make sure they can share this store.
      && (!seriesDimDef || !seriesDimDef.isCalculationCoord)) {
        dimHash += makeHashStrict
        // Use escape character '`' in case that property name contains '$'.
        ? property.replace(/\`/g, '`1').replace(/\$/g, '`2')
        // For better performance, when there are large dimensions, tolerant this defects that hardly meet.
        : property;
      }
      dimHash += '$';
      dimHash += dimTypeShort[type] || 'f';
      if (ordinalMeta) {
        dimHash += ordinalMeta.uid;
      }
      dimHash += '$';
    }
    // Source from endpoint(usually series) will be read differently
    // when seriesLayoutBy or startIndex(which is affected by sourceHeader) are different.
    // So we use this three props as key.
    var source = this.source;
    var hash = [source.seriesLayoutBy, source.startIndex, dimHash].join('$$');
    return {
      dimensions: dims,
      hash: hash
    };
  };
  SeriesDataSchema.prototype.makeOutputDimensionNames = function () {
    var result = [];
    for (var fullDimIdx = 0, seriesDimIdx = 0; fullDimIdx < this._fullDimCount; fullDimIdx++) {
      var name_1 = void 0;
      var seriesDimDef = this.dimensions[seriesDimIdx];
      // The list has been sorted by `storeDimIndex` asc.
      if (seriesDimDef && seriesDimDef.storeDimIndex === fullDimIdx) {
        if (!seriesDimDef.isCalculationCoord) {
          name_1 = seriesDimDef.name;
        }
        seriesDimIdx++;
      } else {
        var sourceDimDef = this.getSourceDimension(fullDimIdx);
        if (sourceDimDef) {
          name_1 = sourceDimDef.name;
        }
      }
      result.push(name_1);
    }
    return result;
  };
  SeriesDataSchema.prototype.appendCalculationDimension = function (dimDef) {
    this.dimensions.push(dimDef);
    dimDef.isCalculationCoord = true;
    this._fullDimCount++;
    // If append dimension on a data store, consider the store
    // might be shared by different series, series dimensions not
    // really map to store dimensions.
    this._updateDimOmitted(true);
  };
  return SeriesDataSchema;
}();

function isSeriesDataSchema(schema) {
  return schema instanceof SeriesDataSchema;
}
function createDimNameMap(dimsDef) {
  var dataDimNameMap = (0,zrender_lib_core_util_js__rspack_import_1.createHashMap)();
  for (var i = 0; i < (dimsDef || []).length; i++) {
    var dimDefItemRaw = dimsDef[i];
    var userDimName = (0,zrender_lib_core_util_js__rspack_import_1.isObject)(dimDefItemRaw) ? dimDefItemRaw.name : dimDefItemRaw;
    if (userDimName != null && dataDimNameMap.get(userDimName) == null) {
      dataDimNameMap.set(userDimName, i);
    }
  }
  return dataDimNameMap;
}
function ensureSourceDimNameMap(source) {
  var innerSource = inner(source);
  return innerSource.dimNameMap || (innerSource.dimNameMap = createDimNameMap(source.dimensionsDefine));
}
function shouldOmitUnusedDimensions(dimCount) {
  return dimCount > 30;
}
__webpack_require__.d(__webpack_exports__, {
}, {
  SeriesDataSchema: SeriesDataSchema,
  createDimNameMap: createDimNameMap,
  ensureSourceDimNameMap: ensureSourceDimNameMap,
  isSeriesDataSchema: isSeriesDataSchema,
  shouldOmitUnusedDimensions: shouldOmitUnusedDimensions
});


}),
31292: (function (__unused_rspack___webpack_module__, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
/* import */ var _util_types_js__rspack_import_6 = __webpack_require__(40333);
/* import */ var _SeriesDimensionDefine_js__rspack_import_4 = __webpack_require__(2088);
/* import */ var zrender_lib_core_util_js__rspack_import_1 = __webpack_require__(75275);
/* import */ var _Source_js__rspack_import_0 = __webpack_require__(17043);
/* import */ var _DataStore_js__rspack_import_3 = __webpack_require__(93349);
/* import */ var _util_model_js__rspack_import_5 = __webpack_require__(53781);
/* import */ var _sourceHelper_js__rspack_import_7 = __webpack_require__(44872);
/* import */ var _SeriesDataSchema_js__rspack_import_2 = __webpack_require__(23619);

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/


/**
 * AUTO-GENERATED FILE. DO NOT MODIFY.
 */

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/








/**
 * For outside usage compat (like echarts-gl are using it).
 */
function createDimensions(source, opt) {
  return prepareSeriesDataSchema(source, opt).dimensions;
}
/**
 * This method builds the relationship between:
 * + "what the coord sys or series requires (see `coordDimensions`)",
 * + "what the user defines (in `encode` and `dimensions`, see `opt.dimensionsDefine` and `opt.encodeDefine`)"
 * + "what the data source provids (see `source`)".
 *
 * Some guess strategy will be adapted if user does not define something.
 * If no 'value' dimension specified, the first no-named dimension will be
 * named as 'value'.
 *
 * @return The results are always sorted by `storeDimIndex` asc.
 */
function prepareSeriesDataSchema(
// TODO: TYPE completeDimensions type
source, opt) {
  if (!(0,_Source_js__rspack_import_0.isSourceInstance)(source)) {
    source = (0,_Source_js__rspack_import_0.createSourceFromSeriesDataOption)(source);
  }
  opt = opt || {};
  var sysDims = opt.coordDimensions || [];
  var dimsDef = opt.dimensionsDefine || source.dimensionsDefine || [];
  var coordDimNameMap = (0,zrender_lib_core_util_js__rspack_import_1.createHashMap)();
  var resultList = [];
  var dimCount = getDimCount(source, sysDims, dimsDef, opt.dimensionsCount);
  // Try to ignore unused dimensions if sharing a high dimension datastore
  // 30 is an experience value.
  var omitUnusedDimensions = opt.canOmitUnusedDimensions && (0,_SeriesDataSchema_js__rspack_import_2.shouldOmitUnusedDimensions)(dimCount);
  var isUsingSourceDimensionsDef = dimsDef === source.dimensionsDefine;
  var dataDimNameMap = isUsingSourceDimensionsDef ? (0,_SeriesDataSchema_js__rspack_import_2.ensureSourceDimNameMap)(source) : (0,_SeriesDataSchema_js__rspack_import_2.createDimNameMap)(dimsDef);
  var encodeDef = opt.encodeDefine;
  if (!encodeDef && opt.encodeDefaulter) {
    encodeDef = opt.encodeDefaulter(source, dimCount);
  }
  var encodeDefMap = (0,zrender_lib_core_util_js__rspack_import_1.createHashMap)(encodeDef);
  var indicesMap = new _DataStore_js__rspack_import_3.CtorInt32Array(dimCount);
  for (var i = 0; i < indicesMap.length; i++) {
    indicesMap[i] = -1;
  }
  function getResultItem(dimIdx) {
    var idx = indicesMap[dimIdx];
    if (idx < 0) {
      var dimDefItemRaw = dimsDef[dimIdx];
      var dimDefItem = (0,zrender_lib_core_util_js__rspack_import_1.isObject)(dimDefItemRaw) ? dimDefItemRaw : {
        name: dimDefItemRaw
      };
      var resultItem = new _SeriesDimensionDefine_js__rspack_import_4["default"]();
      var userDimName = dimDefItem.name;
      if (userDimName != null && dataDimNameMap.get(userDimName) != null) {
        // Only if `series.dimensions` is defined in option
        // displayName, will be set, and dimension will be displayed vertically in
        // tooltip by default.
        resultItem.name = resultItem.displayName = userDimName;
      }
      dimDefItem.type != null && (resultItem.type = dimDefItem.type);
      dimDefItem.displayName != null && (resultItem.displayName = dimDefItem.displayName);
      var newIdx = resultList.length;
      indicesMap[dimIdx] = newIdx;
      resultItem.storeDimIndex = dimIdx;
      resultList.push(resultItem);
      return resultItem;
    }
    return resultList[idx];
  }
  if (!omitUnusedDimensions) {
    for (var i = 0; i < dimCount; i++) {
      getResultItem(i);
    }
  }
  // Set `coordDim` and `coordDimIndex` by `encodeDefMap` and normalize `encodeDefMap`.
  encodeDefMap.each(function (dataDimsRaw, coordDim) {
    var dataDims = (0,_util_model_js__rspack_import_5.normalizeToArray)(dataDimsRaw).slice();
    // Note: It is allowed that `dataDims.length` is `0`, e.g., options is
    // `{encode: {x: -1, y: 1}}`. Should not filter anything in
    // this case.
    if (dataDims.length === 1 && !(0,zrender_lib_core_util_js__rspack_import_1.isString)(dataDims[0]) && dataDims[0] < 0) {
      encodeDefMap.set(coordDim, false);
      return;
    }
    var validDataDims = encodeDefMap.set(coordDim, []);
    (0,zrender_lib_core_util_js__rspack_import_1.each)(dataDims, function (resultDimIdxOrName, idx) {
      // The input resultDimIdx can be dim name or index.
      var resultDimIdx = (0,zrender_lib_core_util_js__rspack_import_1.isString)(resultDimIdxOrName) ? dataDimNameMap.get(resultDimIdxOrName) : resultDimIdxOrName;
      if (resultDimIdx != null && resultDimIdx < dimCount) {
        validDataDims[idx] = resultDimIdx;
        applyDim(getResultItem(resultDimIdx), coordDim, idx);
      }
    });
  });
  // Apply templates and default order from `sysDims`.
  var availDimIdx = 0;
  (0,zrender_lib_core_util_js__rspack_import_1.each)(sysDims, function (sysDimItemRaw) {
    var coordDim;
    var sysDimItemDimsDef;
    var sysDimItemOtherDims;
    var sysDimItem;
    if ((0,zrender_lib_core_util_js__rspack_import_1.isString)(sysDimItemRaw)) {
      coordDim = sysDimItemRaw;
      sysDimItem = {};
    } else {
      sysDimItem = sysDimItemRaw;
      coordDim = sysDimItem.name;
      var ordinalMeta = sysDimItem.ordinalMeta;
      sysDimItem.ordinalMeta = null;
      sysDimItem = (0,zrender_lib_core_util_js__rspack_import_1.extend)({}, sysDimItem);
      sysDimItem.ordinalMeta = ordinalMeta;
      // `coordDimIndex` should not be set directly.
      sysDimItemDimsDef = sysDimItem.dimsDef;
      sysDimItemOtherDims = sysDimItem.otherDims;
      sysDimItem.name = sysDimItem.coordDim = sysDimItem.coordDimIndex = sysDimItem.dimsDef = sysDimItem.otherDims = null;
    }
    var dataDims = encodeDefMap.get(coordDim);
    // negative resultDimIdx means no need to mapping.
    if (dataDims === false) {
      return;
    }
    dataDims = (0,_util_model_js__rspack_import_5.normalizeToArray)(dataDims);
    // dimensions provides default dim sequences.
    if (!dataDims.length) {
      for (var i = 0; i < (sysDimItemDimsDef && sysDimItemDimsDef.length || 1); i++) {
        while (availDimIdx < dimCount && getResultItem(availDimIdx).coordDim != null) {
          availDimIdx++;
        }
        availDimIdx < dimCount && dataDims.push(availDimIdx++);
      }
    }
    // Apply templates.
    (0,zrender_lib_core_util_js__rspack_import_1.each)(dataDims, function (resultDimIdx, coordDimIndex) {
      var resultItem = getResultItem(resultDimIdx);
      // Coordinate system has a higher priority on dim type than source.
      if (isUsingSourceDimensionsDef && sysDimItem.type != null) {
        resultItem.type = sysDimItem.type;
      }
      applyDim((0,zrender_lib_core_util_js__rspack_import_1.defaults)(resultItem, sysDimItem), coordDim, coordDimIndex);
      if (resultItem.name == null && sysDimItemDimsDef) {
        var sysDimItemDimsDefItem = sysDimItemDimsDef[coordDimIndex];
        !(0,zrender_lib_core_util_js__rspack_import_1.isObject)(sysDimItemDimsDefItem) && (sysDimItemDimsDefItem = {
          name: sysDimItemDimsDefItem
        });
        resultItem.name = resultItem.displayName = sysDimItemDimsDefItem.name;
        resultItem.defaultTooltip = sysDimItemDimsDefItem.defaultTooltip;
      }
      // FIXME refactor, currently only used in case: {otherDims: {tooltip: false}}
      sysDimItemOtherDims && (0,zrender_lib_core_util_js__rspack_import_1.defaults)(resultItem.otherDims, sysDimItemOtherDims);
    });
  });
  function applyDim(resultItem, coordDim, coordDimIndex) {
    if (_util_types_js__rspack_import_6.VISUAL_DIMENSIONS.get(coordDim) != null) {
      resultItem.otherDims[coordDim] = coordDimIndex;
    } else {
      resultItem.coordDim = coordDim;
      resultItem.coordDimIndex = coordDimIndex;
      coordDimNameMap.set(coordDim, true);
    }
  }
  // Make sure the first extra dim is 'value'.
  var generateCoord = opt.generateCoord;
  var generateCoordCount = opt.generateCoordCount;
  var fromZero = generateCoordCount != null;
  generateCoordCount = generateCoord ? generateCoordCount || 1 : 0;
  var extra = generateCoord || 'value';
  function ifNoNameFillWithCoordName(resultItem) {
    if (resultItem.name == null) {
      // Duplication will be removed in the next step.
      resultItem.name = resultItem.coordDim;
    }
  }
  // Set dim `name` and other `coordDim` and other props.
  if (!omitUnusedDimensions) {
    for (var resultDimIdx = 0; resultDimIdx < dimCount; resultDimIdx++) {
      var resultItem = getResultItem(resultDimIdx);
      var coordDim = resultItem.coordDim;
      if (coordDim == null) {
        // TODO no need to generate coordDim for isExtraCoord?
        resultItem.coordDim = genCoordDimName(extra, coordDimNameMap, fromZero);
        resultItem.coordDimIndex = 0;
        // Series specified generateCoord is using out.
        if (!generateCoord || generateCoordCount <= 0) {
          resultItem.isExtraCoord = true;
        }
        generateCoordCount--;
      }
      ifNoNameFillWithCoordName(resultItem);
      if (resultItem.type == null && ((0,_sourceHelper_js__rspack_import_7.guessOrdinal)(source, resultDimIdx) === _sourceHelper_js__rspack_import_7.BE_ORDINAL.Must
      // Consider the case:
      // {
      //    dataset: {source: [
      //        ['2001', 123],
      //        ['2002', 456],
      //        ...
      //        ['The others', 987],
      //    ]},
      //    series: {type: 'pie'}
      // }
      // The first column should better be treated as a "ordinal" although it
      // might not be detected as an "ordinal" by `guessOrdinal`.
      || resultItem.isExtraCoord && (resultItem.otherDims.itemName != null || resultItem.otherDims.seriesName != null))) {
        resultItem.type = 'ordinal';
      }
    }
  } else {
    (0,zrender_lib_core_util_js__rspack_import_1.each)(resultList, function (resultItem) {
      // PENDING: guessOrdinal or let user specify type: 'ordinal' manually?
      ifNoNameFillWithCoordName(resultItem);
    });
    // Sort dimensions: there are some rule that use the last dim as label,
    // and for some latter travel process easier.
    resultList.sort(function (item0, item1) {
      return item0.storeDimIndex - item1.storeDimIndex;
    });
  }
  (0,_util_model_js__rspack_import_5.removeDuplicates)(resultList, function (item) {
    return item.name;
  }, function (item, existingCount) {
    if (existingCount > 0) {
      // Starts from 0.
      item.name = item.name + (existingCount - 1);
    }
  });
  return new _SeriesDataSchema_js__rspack_import_2.SeriesDataSchema({
    source: source,
    dimensions: resultList,
    fullDimensionCount: dimCount,
    dimensionOmitted: omitUnusedDimensions
  });
}
// ??? TODO
// Originally detect dimCount by data[0]. Should we
// optimize it to only by sysDims and dimensions and encode.
// So only necessary dims will be initialized.
// But
// (1) custom series should be considered. where other dims
// may be visited.
// (2) sometimes user need to calculate bubble size or use visualMap
// on other dimensions besides coordSys needed.
// So, dims that is not used by system, should be shared in data store?
function getDimCount(source, sysDims, dimsDef, optDimCount) {
  // Note that the result dimCount should not small than columns count
  // of data, otherwise `dataDimNameMap` checking will be incorrect.
  var dimCount = Math.max(source.dimensionsDetectedCount || 1, sysDims.length, dimsDef.length, optDimCount || 0);
  (0,zrender_lib_core_util_js__rspack_import_1.each)(sysDims, function (sysDimItem) {
    var sysDimItemDimsDef;
    if ((0,zrender_lib_core_util_js__rspack_import_1.isObject)(sysDimItem) && (sysDimItemDimsDef = sysDimItem.dimsDef)) {
      dimCount = Math.max(dimCount, sysDimItemDimsDef.length);
    }
  });
  return dimCount;
}
function genCoordDimName(name, map, fromZero) {
  if (fromZero || map.hasKey(name)) {
    var i = 0;
    while (map.hasKey(name + i)) {
      i++;
    }
    name += i;
  }
  map.set(name, true);
  return name;
}
__webpack_require__.d(__webpack_exports__, {
}, {
  createDimensions: createDimensions,
  "default": prepareSeriesDataSchema
});


}),
13988: (function (__unused_rspack___webpack_module__, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
/* import */ var zrender_lib_core_util_js__rspack_import_2 = __webpack_require__(75275);
/* import */ var _util_model_js__rspack_import_4 = __webpack_require__(53781);
/* import */ var _Source_js__rspack_import_0 = __webpack_require__(17043);
/* import */ var _util_types_js__rspack_import_1 = __webpack_require__(40333);
/* import */ var _util_log_js__rspack_import_3 = __webpack_require__(44002);

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/


/**
 * AUTO-GENERATED FILE. DO NOT MODIFY.
 */

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/
var _a, _b, _c, _d;
// TODO
// ??? refactor? check the outer usage of data provider.
// merge with defaultDimValueGetter?





var providerMethods;
var mountMethods;
/**
 * If normal array used, mutable chunk size is supported.
 * If typed array used, chunk size must be fixed.
 */
var DefaultDataProvider = /** @class */function () {
  function DefaultDataProvider(sourceParam, dimSize) {
    // let source: Source;
    var source = !(0,_Source_js__rspack_import_0.isSourceInstance)(sourceParam) ? (0,_Source_js__rspack_import_0.createSourceFromSeriesDataOption)(sourceParam) : sourceParam;
    // declare source is Source;
    this._source = source;
    var data = this._data = source.data;
    var sourceFormat = source.sourceFormat;
    var seriesLayoutBy = source.seriesLayoutBy;
    // Typed array. TODO IE10+?
    if (sourceFormat === _util_types_js__rspack_import_1.SOURCE_FORMAT_TYPED_ARRAY) {
      if (false) {}
      this._offset = 0;
      this._dimSize = dimSize;
      this._data = data;
    }
    if (false) { var validator }
    mountMethods(this, data, source);
  }
  DefaultDataProvider.prototype.getSource = function () {
    return this._source;
  };
  DefaultDataProvider.prototype.count = function () {
    return 0;
  };
  DefaultDataProvider.prototype.getItem = function (idx, out) {
    return;
  };
  DefaultDataProvider.prototype.appendData = function (newData) {};
  DefaultDataProvider.prototype.clean = function () {};
  DefaultDataProvider.protoInitialize = function () {
    // PENDING: To avoid potential incompat (e.g., prototype
    // is visited somewhere), still init them on prototype.
    var proto = DefaultDataProvider.prototype;
    proto.pure = false;
    proto.persistent = true;
  }();
  DefaultDataProvider.internalField = function () {
    var _a;
    mountMethods = function (provider, data, source) {
      var sourceFormat = source.sourceFormat;
      var seriesLayoutBy = source.seriesLayoutBy;
      var startIndex = source.startIndex;
      var dimsDef = source.dimensionsDefine;
      var methods = providerMethods[getMethodMapKey(sourceFormat, seriesLayoutBy)];
      if (false) {}
      (0,zrender_lib_core_util_js__rspack_import_2.extend)(provider, methods);
      if (sourceFormat === _util_types_js__rspack_import_1.SOURCE_FORMAT_TYPED_ARRAY) {
        provider.getItem = getItemForTypedArray;
        provider.count = countForTypedArray;
        provider.fillStorage = fillStorageForTypedArray;
      } else {
        var rawItemGetter = getRawSourceItemGetter(sourceFormat, seriesLayoutBy);
        provider.getItem = (0,zrender_lib_core_util_js__rspack_import_2.bind)(rawItemGetter, null, data, startIndex, dimsDef);
        var rawCounter = getRawSourceDataCounter(sourceFormat, seriesLayoutBy);
        provider.count = (0,zrender_lib_core_util_js__rspack_import_2.bind)(rawCounter, null, data, startIndex, dimsDef);
      }
    };
    var getItemForTypedArray = function (idx, out) {
      idx = idx - this._offset;
      out = out || [];
      var data = this._data;
      var dimSize = this._dimSize;
      var offset = dimSize * idx;
      for (var i = 0; i < dimSize; i++) {
        out[i] = data[offset + i];
      }
      return out;
    };
    var fillStorageForTypedArray = function (start, end, storage, extent) {
      var data = this._data;
      var dimSize = this._dimSize;
      for (var dim = 0; dim < dimSize; dim++) {
        var dimExtent = extent[dim];
        var min = dimExtent[0] == null ? Infinity : dimExtent[0];
        var max = dimExtent[1] == null ? -Infinity : dimExtent[1];
        var count = end - start;
        var arr = storage[dim];
        for (var i = 0; i < count; i++) {
          // appendData with TypedArray will always do replace in provider.
          var val = data[i * dimSize + dim];
          arr[start + i] = val;
          val < min && (min = val);
          val > max && (max = val);
        }
        dimExtent[0] = min;
        dimExtent[1] = max;
      }
    };
    var countForTypedArray = function () {
      return this._data ? this._data.length / this._dimSize : 0;
    };
    providerMethods = (_a = {}, _a[_util_types_js__rspack_import_1.SOURCE_FORMAT_ARRAY_ROWS + '_' + _util_types_js__rspack_import_1.SERIES_LAYOUT_BY_COLUMN] = {
      pure: true,
      appendData: appendDataSimply
    }, _a[_util_types_js__rspack_import_1.SOURCE_FORMAT_ARRAY_ROWS + '_' + _util_types_js__rspack_import_1.SERIES_LAYOUT_BY_ROW] = {
      pure: true,
      appendData: function () {
        throw new Error('Do not support appendData when set seriesLayoutBy: "row".');
      }
    }, _a[_util_types_js__rspack_import_1.SOURCE_FORMAT_OBJECT_ROWS] = {
      pure: true,
      appendData: appendDataSimply
    }, _a[_util_types_js__rspack_import_1.SOURCE_FORMAT_KEYED_COLUMNS] = {
      pure: true,
      appendData: function (newData) {
        var data = this._data;
        (0,zrender_lib_core_util_js__rspack_import_2.each)(newData, function (newCol, key) {
          var oldCol = data[key] || (data[key] = []);
          for (var i = 0; i < (newCol || []).length; i++) {
            oldCol.push(newCol[i]);
          }
        });
      }
    }, _a[_util_types_js__rspack_import_1.SOURCE_FORMAT_ORIGINAL] = {
      appendData: appendDataSimply
    }, _a[_util_types_js__rspack_import_1.SOURCE_FORMAT_TYPED_ARRAY] = {
      persistent: false,
      pure: true,
      appendData: function (newData) {
        if (false) {}
        this._data = newData;
      },
      // Clean self if data is already used.
      clean: function () {
        // PENDING
        this._offset += this.count();
        this._data = null;
      }
    }, _a);
    function appendDataSimply(newData) {
      for (var i = 0; i < newData.length; i++) {
        this._data.push(newData[i]);
      }
    }
  }();
  return DefaultDataProvider;
}();

var validateSimply = function (rawData) {
  if (!(0,zrender_lib_core_util_js__rspack_import_2.isArray)(rawData)) {
    (0,_util_log_js__rspack_import_3.error)('series.data or dataset.source must be an array.');
  }
};
/**
 * Only run in dev mode - hint users for debug.
 */
var rawSourceDataValidatorMap = (_a = {}, _a[_util_types_js__rspack_import_1.SOURCE_FORMAT_ARRAY_ROWS + '_' + _util_types_js__rspack_import_1.SERIES_LAYOUT_BY_COLUMN] = validateSimply, _a[_util_types_js__rspack_import_1.SOURCE_FORMAT_ARRAY_ROWS + '_' + _util_types_js__rspack_import_1.SERIES_LAYOUT_BY_ROW] = validateSimply, _a[_util_types_js__rspack_import_1.SOURCE_FORMAT_OBJECT_ROWS] = validateSimply, _a[_util_types_js__rspack_import_1.SOURCE_FORMAT_KEYED_COLUMNS] = function (rawData, dimsDef) {
  for (var i = 0; i < dimsDef.length; i++) {
    var dimName = dimsDef[i].name;
    if (dimName == null) {
      (0,_util_log_js__rspack_import_3.error)('dimension name must not be null/undefined.');
    }
  }
}, _a[_util_types_js__rspack_import_1.SOURCE_FORMAT_ORIGINAL] = validateSimply, _a);
var getItemSimply = function (rawData, startIndex, dimsDef, idx) {
  return rawData[idx];
};
var rawSourceItemGetterMap = (_b = {}, _b[_util_types_js__rspack_import_1.SOURCE_FORMAT_ARRAY_ROWS + '_' + _util_types_js__rspack_import_1.SERIES_LAYOUT_BY_COLUMN] = function (rawData, startIndex, dimsDef, idx) {
  return rawData[idx + startIndex];
}, _b[_util_types_js__rspack_import_1.SOURCE_FORMAT_ARRAY_ROWS + '_' + _util_types_js__rspack_import_1.SERIES_LAYOUT_BY_ROW] = function (rawData, startIndex, dimsDef, idx, out) {
  idx += startIndex;
  var item = out || [];
  var data = rawData;
  for (var i = 0; i < data.length; i++) {
    var row = data[i];
    item[i] = row ? row[idx] : null;
  }
  return item;
}, _b[_util_types_js__rspack_import_1.SOURCE_FORMAT_OBJECT_ROWS] = getItemSimply, _b[_util_types_js__rspack_import_1.SOURCE_FORMAT_KEYED_COLUMNS] = function (rawData, startIndex, dimsDef, idx, out) {
  var item = out || [];
  for (var i = 0; i < dimsDef.length; i++) {
    var dimName = dimsDef[i].name;
    var col = dimName != null ? rawData[dimName] : null;
    item[i] = col ? col[idx] : null;
  }
  return item;
}, _b[_util_types_js__rspack_import_1.SOURCE_FORMAT_ORIGINAL] = getItemSimply, _b);
function getRawSourceItemGetter(sourceFormat, seriesLayoutBy) {
  var method = rawSourceItemGetterMap[getMethodMapKey(sourceFormat, seriesLayoutBy)];
  if (false) {}
  return method;
}
var countSimply = function (rawData, startIndex, dimsDef) {
  return rawData.length;
};
var rawSourceDataCounterMap = (_c = {}, _c[_util_types_js__rspack_import_1.SOURCE_FORMAT_ARRAY_ROWS + '_' + _util_types_js__rspack_import_1.SERIES_LAYOUT_BY_COLUMN] = function (rawData, startIndex, dimsDef) {
  return Math.max(0, rawData.length - startIndex);
}, _c[_util_types_js__rspack_import_1.SOURCE_FORMAT_ARRAY_ROWS + '_' + _util_types_js__rspack_import_1.SERIES_LAYOUT_BY_ROW] = function (rawData, startIndex, dimsDef) {
  var row = rawData[0];
  return row ? Math.max(0, row.length - startIndex) : 0;
}, _c[_util_types_js__rspack_import_1.SOURCE_FORMAT_OBJECT_ROWS] = countSimply, _c[_util_types_js__rspack_import_1.SOURCE_FORMAT_KEYED_COLUMNS] = function (rawData, startIndex, dimsDef) {
  var dimName = dimsDef[0].name;
  var col = dimName != null ? rawData[dimName] : null;
  return col ? col.length : 0;
}, _c[_util_types_js__rspack_import_1.SOURCE_FORMAT_ORIGINAL] = countSimply, _c);
function getRawSourceDataCounter(sourceFormat, seriesLayoutBy) {
  var method = rawSourceDataCounterMap[getMethodMapKey(sourceFormat, seriesLayoutBy)];
  if (false) {}
  return method;
}
var getRawValueSimply = function (dataItem, dimIndex, property) {
  return dataItem[dimIndex];
};
var rawSourceValueGetterMap = (_d = {}, _d[_util_types_js__rspack_import_1.SOURCE_FORMAT_ARRAY_ROWS] = getRawValueSimply, _d[_util_types_js__rspack_import_1.SOURCE_FORMAT_OBJECT_ROWS] = function (dataItem, dimIndex, property) {
  return dataItem[property];
}, _d[_util_types_js__rspack_import_1.SOURCE_FORMAT_KEYED_COLUMNS] = getRawValueSimply, _d[_util_types_js__rspack_import_1.SOURCE_FORMAT_ORIGINAL] = function (dataItem, dimIndex, property) {
  // FIXME: In some case (markpoint in geo (geo-map.html)),
  // dataItem is {coord: [...]}
  var value = (0,_util_model_js__rspack_import_4.getDataItemValue)(dataItem);
  return !(value instanceof Array) ? value : value[dimIndex];
}, _d[_util_types_js__rspack_import_1.SOURCE_FORMAT_TYPED_ARRAY] = getRawValueSimply, _d);
function getRawSourceValueGetter(sourceFormat) {
  var method = rawSourceValueGetterMap[sourceFormat];
  if (false) {}
  return method;
}
function getMethodMapKey(sourceFormat, seriesLayoutBy) {
  return sourceFormat === _util_types_js__rspack_import_1.SOURCE_FORMAT_ARRAY_ROWS ? sourceFormat + '_' + seriesLayoutBy : sourceFormat;
}
// ??? FIXME can these logic be more neat: getRawValue, getRawDataItem,
// Consider persistent.
// Caution: why use raw value to display on label or tooltip?
// A reason is to avoid format. For example time value we do not know
// how to format is expected. More over, if stack is used, calculated
// value may be 0.91000000001, which have brings trouble to display.
// TODO: consider how to treat null/undefined/NaN when display?
function retrieveRawValue(data, dataIndex,
// If dimIndex is null/undefined, return OptionDataItem.
// Otherwise, return OptionDataValue.
dim) {
  if (!data) {
    return;
  }
  // Consider data may be not persistent.
  var dataItem = data.getRawDataItem(dataIndex);
  if (dataItem == null) {
    return;
  }
  var store = data.getStore();
  var sourceFormat = store.getSource().sourceFormat;
  if (dim != null) {
    var dimIndex = data.getDimensionIndex(dim);
    var property = store.getDimensionProperty(dimIndex);
    return getRawSourceValueGetter(sourceFormat)(dataItem, dimIndex, property);
  } else {
    var result = dataItem;
    if (sourceFormat === _util_types_js__rspack_import_1.SOURCE_FORMAT_ORIGINAL) {
      result = (0,_util_model_js__rspack_import_4.getDataItemValue)(dataItem);
    }
    return result;
  }
}
/**
 * Compatible with some cases (in pie, map) like:
 * data: [{name: 'xx', value: 5, selected: true}, ...]
 * where only sourceFormat is 'original' and 'objectRows' supported.
 *
 * // TODO
 * Supported detail options in data item when using 'arrayRows'.
 *
 * @param data
 * @param dataIndex
 * @param attr like 'selected'
 */
function retrieveRawAttr(data, dataIndex, attr) {
  if (!data) {
    return;
  }
  var sourceFormat = data.getStore().getSource().sourceFormat;
  if (sourceFormat !== _util_types_js__rspack_import_1.SOURCE_FORMAT_ORIGINAL && sourceFormat !== _util_types_js__rspack_import_1.SOURCE_FORMAT_OBJECT_ROWS) {
    return;
  }
  var dataItem = data.getRawDataItem(dataIndex);
  if (sourceFormat === _util_types_js__rspack_import_1.SOURCE_FORMAT_ORIGINAL && !(0,zrender_lib_core_util_js__rspack_import_2.isObject)(dataItem)) {
    dataItem = null;
  }
  if (dataItem) {
    return dataItem[attr];
  }
}
__webpack_require__.d(__webpack_exports__, {
}, {
  DefaultDataProvider: DefaultDataProvider,
  getRawSourceDataCounter: getRawSourceDataCounter,
  getRawSourceItemGetter: getRawSourceItemGetter,
  getRawSourceValueGetter: getRawSourceValueGetter,
  retrieveRawAttr: retrieveRawAttr,
  retrieveRawValue: retrieveRawValue
});


}),
58337: (function (__unused_rspack___webpack_module__, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
/* import */ var zrender_lib_core_util_js__rspack_import_0 = __webpack_require__(75275);
/* import */ var _SeriesDataSchema_js__rspack_import_1 = __webpack_require__(23619);

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/


/**
 * AUTO-GENERATED FILE. DO NOT MODIFY.
 */

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/


/**
 * Note that it is too complicated to support 3d stack by value
 * (have to create two-dimension inverted index), so in 3d case
 * we just support that stacked by index.
 *
 * Stack is calculated in `src/processor/dataStack.ts`.
 *
 * @param seriesModel
 * @param dimensionsInput The same as the input of <module:echarts/data/SeriesData>.
 *        The input will be modified.
 * @param opt
 * @param opt.stackedCoordDimension Specify a coord dimension if needed.
 * @param opt.byIndex=false
 * @return calculationInfo
 * {
 *     stackedDimension: string
 *     stackedByDimension: string
 *     isStackedByIndex: boolean
 *     stackedOverDimension: string
 *     stackResultDimension: string
 * }
 */
function enableDataStack(seriesModel, dimensionsInput, opt) {
  opt = opt || {};
  var byIndex = opt.byIndex;
  var stackedCoordDimension = opt.stackedCoordDimension;
  var dimensionDefineList;
  var schema;
  var store;
  if (isLegacyDimensionsInput(dimensionsInput)) {
    dimensionDefineList = dimensionsInput;
  } else {
    schema = dimensionsInput.schema;
    dimensionDefineList = schema.dimensions;
    store = dimensionsInput.store;
  }
  // compatible: when `stack` is set as '', do not stack.
  var mayStack = !!(seriesModel && seriesModel.get('stack'));
  var stackedByDimInfo;
  var stackedDimInfo;
  var stackResultDimension;
  var stackedOverDimension;
  var allDimTypesAreNotOrdinalAndTime = true;
  function dimTypeIsNotOrdinalAndTime(dimensionInfo) {
    return dimensionInfo.type !== 'ordinal' && dimensionInfo.type !== 'time';
  }
  (0,zrender_lib_core_util_js__rspack_import_0.each)(dimensionDefineList, function (dimensionInfo, index) {
    if ((0,zrender_lib_core_util_js__rspack_import_0.isString)(dimensionInfo)) {
      dimensionDefineList[index] = dimensionInfo = {
        name: dimensionInfo
      };
    }
    if (!dimTypeIsNotOrdinalAndTime(dimensionInfo)) {
      allDimTypesAreNotOrdinalAndTime = false;
    }
  });
  (0,zrender_lib_core_util_js__rspack_import_0.each)(dimensionDefineList, function (dimensionInfo, index) {
    if (mayStack && !dimensionInfo.isExtraCoord) {
      // Find the first ordinal dimension as the stackedByDimInfo.
      if (!byIndex && !stackedByDimInfo && dimensionInfo.ordinalMeta) {
        stackedByDimInfo = dimensionInfo;
      }
      // Find the first stackable dimension as the stackedDimInfo.
      if (!stackedDimInfo && dimTypeIsNotOrdinalAndTime(dimensionInfo)
      // FIXME:
      //  This rule MUST be consistent with `Cartesian2D['getBaseAxis']` and `Polar['getBaseAxis']`
      //  Need refactor - merge them!
      //  See comments in `Cartesian2D['getBaseAxis']` for details.
      && (!allDimTypesAreNotOrdinalAndTime || dimensionInfo.coordDim !== 'x' && dimensionInfo.coordDim !== 'angle') && (!stackedCoordDimension || stackedCoordDimension === dimensionInfo.coordDim)) {
        stackedDimInfo = dimensionInfo;
      }
    }
  });
  if (stackedDimInfo && !byIndex && !stackedByDimInfo) {
    // "Stack by data index" makes sense only if users provide carefully constructed data - any
    // mismatch or absence of data items can cause incorrect results. By "Stack by data index"
    // is more performant - no hashmap is required.
    // PENDING:
    //  Compatible with previous design, non-category axis ("value"/"log"/"time" axis) can only
    //  stack by index. "Stack by value" will not be supported until concrete requirements arise.
    byIndex = true;
  }
  if (stackedDimInfo) {
    // Use a weird name that not duplicated with other names.
    // Also need to use seriesModel.id as postfix because different
    // series may share same data store. The stack dimension needs to be distinguished.
    stackResultDimension = '__\0ecstackresult_' + seriesModel.id;
    stackedOverDimension = '__\0ecstackedover_' + seriesModel.id;
    // Create inverted index to fast query index by value.
    if (stackedByDimInfo) {
      stackedByDimInfo.createInvertedIndices = true;
    }
    var stackedDimCoordDim_1 = stackedDimInfo.coordDim;
    var stackedDimType = stackedDimInfo.type;
    var stackedDimCoordIndex_1 = 0;
    (0,zrender_lib_core_util_js__rspack_import_0.each)(dimensionDefineList, function (dimensionInfo) {
      if (dimensionInfo.coordDim === stackedDimCoordDim_1) {
        stackedDimCoordIndex_1++;
      }
    });
    var stackedOverDimensionDefine = {
      name: stackResultDimension,
      coordDim: stackedDimCoordDim_1,
      coordDimIndex: stackedDimCoordIndex_1,
      type: stackedDimType,
      isExtraCoord: true,
      isCalculationCoord: true,
      storeDimIndex: dimensionDefineList.length
    };
    var stackResultDimensionDefine = {
      name: stackedOverDimension,
      // This dimension contains stack base (generally, 0), so do not set it as
      // `stackedDimCoordDim` to avoid extent calculation, consider log scale.
      coordDim: stackedOverDimension,
      coordDimIndex: stackedDimCoordIndex_1 + 1,
      type: stackedDimType,
      isExtraCoord: true,
      isCalculationCoord: true,
      storeDimIndex: dimensionDefineList.length + 1
    };
    if (schema) {
      if (store) {
        stackedOverDimensionDefine.storeDimIndex = store.ensureCalculationDimension(stackedOverDimension, stackedDimType);
        stackResultDimensionDefine.storeDimIndex = store.ensureCalculationDimension(stackResultDimension, stackedDimType);
      }
      schema.appendCalculationDimension(stackedOverDimensionDefine);
      schema.appendCalculationDimension(stackResultDimensionDefine);
    } else {
      dimensionDefineList.push(stackedOverDimensionDefine);
      dimensionDefineList.push(stackResultDimensionDefine);
    }
  }
  return {
    stackedDimension: stackedDimInfo && stackedDimInfo.name,
    stackedByDimension: stackedByDimInfo && stackedByDimInfo.name,
    isStackedByIndex: byIndex,
    stackedOverDimension: stackedOverDimension,
    stackResultDimension: stackResultDimension
  };
}
function isLegacyDimensionsInput(dimensionsInput) {
  return !(0,_SeriesDataSchema_js__rspack_import_1.isSeriesDataSchema)(dimensionsInput.schema);
}
function isDimensionStacked(data, stackedDim) {
  // Each single series only maps to one pair of axis. So we do not need to
  // check stackByDim, whatever stacked by a dimension or stacked by index.
  return !!stackedDim && stackedDim === data.getCalculationInfo('stackedDimension');
}
function getStackedDimension(data, targetDim) {
  return isDimensionStacked(data, targetDim) ? data.getCalculationInfo('stackResultDimension') : targetDim;
}
__webpack_require__.d(__webpack_exports__, {
}, {
  enableDataStack: enableDataStack,
  getStackedDimension: getStackedDimension,
  isDimensionStacked: isDimensionStacked
});


}),
94276: (function (__unused_rspack___webpack_module__, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
/* import */ var _util_number_js__rspack_import_1 = __webpack_require__(46823);
/* import */ var zrender_lib_core_util_js__rspack_import_0 = __webpack_require__(75275);
/* import */ var _util_log_js__rspack_import_2 = __webpack_require__(44002);

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/


/**
 * AUTO-GENERATED FILE. DO NOT MODIFY.
 */

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/



// --------- START: Parsers --------
/**
 * Convert raw the value in to inner value in List.
 *
 * [Performance sensitive]
 *
 * [Caution]: this is the key logic of user value parser.
 * For backward compatibility, do not modify it until you have to!
 */
function parseDataValue(value,
// For high performance, do not omit the second param.
opt) {
  // Performance sensitive.
  var dimType = opt && opt.type;
  if (dimType === 'ordinal') {
    // If given value is a category string
    return value;
  }
  if (dimType === 'time'
  // spead up when using timestamp
  && !(0,zrender_lib_core_util_js__rspack_import_0.isNumber)(value) && value != null && value !== '-') {
    value = +(0,_util_number_js__rspack_import_1.parseDate)(value);
  }
  // dimType defaults 'number'.
  // If dimType is not ordinal and value is null or undefined or NaN or '-',
  // parse to NaN.
  // number-like string (like ' 123 ') can be converted to a number.
  // where null/undefined or other string will be converted to NaN.
  return value == null || value === '' ? NaN
  // If string (like '-'), using '+' parse to NaN
  // If object, also parse to NaN
  : Number(value);
}
;
var valueParserMap = (0,zrender_lib_core_util_js__rspack_import_0.createHashMap)({
  'number': function (val) {
    // Do not use `numericToNumber` here. We have `numericToNumber` by default.
    // Here the number parser can have loose rule:
    // enable to cut suffix: "120px" => 120, "14%" => 14.
    return parseFloat(val);
  },
  'time': function (val) {
    // return timestamp.
    return +(0,_util_number_js__rspack_import_1.parseDate)(val);
  },
  'trim': function (val) {
    return (0,zrender_lib_core_util_js__rspack_import_0.isString)(val) ? (0,zrender_lib_core_util_js__rspack_import_0.trim)(val) : val;
  }
});
function getRawValueParser(type) {
  return valueParserMap.get(type);
}
var ORDER_COMPARISON_OP_MAP = {
  lt: function (lval, rval) {
    return lval < rval;
  },
  lte: function (lval, rval) {
    return lval <= rval;
  },
  gt: function (lval, rval) {
    return lval > rval;
  },
  gte: function (lval, rval) {
    return lval >= rval;
  }
};
var FilterOrderComparator = /** @class */function () {
  function FilterOrderComparator(op, rval) {
    if (!(0,zrender_lib_core_util_js__rspack_import_0.isNumber)(rval)) {
      var errMsg = '';
      if (false) {}
      (0,_util_log_js__rspack_import_2.throwError)(errMsg);
    }
    this._opFn = ORDER_COMPARISON_OP_MAP[op];
    this._rvalFloat = (0,_util_number_js__rspack_import_1.numericToNumber)(rval);
  }
  // Performance sensitive.
  FilterOrderComparator.prototype.evaluate = function (lval) {
    // Most cases is 'number', and typeof maybe 10 times faseter than parseFloat.
    return (0,zrender_lib_core_util_js__rspack_import_0.isNumber)(lval) ? this._opFn(lval, this._rvalFloat) : this._opFn((0,_util_number_js__rspack_import_1.numericToNumber)(lval), this._rvalFloat);
  };
  return FilterOrderComparator;
}();
var SortOrderComparator = /** @class */function () {
  /**
   * @param order by default: 'asc'
   * @param incomparable by default: Always on the tail.
   *        That is, if 'asc' => 'max', if 'desc' => 'min'
   *        See the definition of "incomparable" in [SORT_COMPARISON_RULE].
   */
  function SortOrderComparator(order, incomparable) {
    var isDesc = order === 'desc';
    this._resultLT = isDesc ? 1 : -1;
    if (incomparable == null) {
      incomparable = isDesc ? 'min' : 'max';
    }
    this._incomparable = incomparable === 'min' ? -Infinity : Infinity;
  }
  // See [SORT_COMPARISON_RULE].
  // Performance sensitive.
  SortOrderComparator.prototype.evaluate = function (lval, rval) {
    // Most cases is 'number', and typeof maybe 10 times faseter than parseFloat.
    var lvalFloat = (0,zrender_lib_core_util_js__rspack_import_0.isNumber)(lval) ? lval : (0,_util_number_js__rspack_import_1.numericToNumber)(lval);
    var rvalFloat = (0,zrender_lib_core_util_js__rspack_import_0.isNumber)(rval) ? rval : (0,_util_number_js__rspack_import_1.numericToNumber)(rval);
    var lvalNotNumeric = isNaN(lvalFloat);
    var rvalNotNumeric = isNaN(rvalFloat);
    if (lvalNotNumeric) {
      lvalFloat = this._incomparable;
    }
    if (rvalNotNumeric) {
      rvalFloat = this._incomparable;
    }
    if (lvalNotNumeric && rvalNotNumeric) {
      var lvalIsStr = (0,zrender_lib_core_util_js__rspack_import_0.isString)(lval);
      var rvalIsStr = (0,zrender_lib_core_util_js__rspack_import_0.isString)(rval);
      if (lvalIsStr) {
        lvalFloat = rvalIsStr ? lval : 0;
      }
      if (rvalIsStr) {
        rvalFloat = lvalIsStr ? rval : 0;
      }
    }
    return lvalFloat < rvalFloat ? this._resultLT : lvalFloat > rvalFloat ? -this._resultLT : 0;
  };
  return SortOrderComparator;
}();

var FilterEqualityComparator = /** @class */function () {
  function FilterEqualityComparator(isEq, rval) {
    this._rval = rval;
    this._isEQ = isEq;
    this._rvalTypeof = typeof rval;
    this._rvalFloat = (0,_util_number_js__rspack_import_1.numericToNumber)(rval);
  }
  // Performance sensitive.
  FilterEqualityComparator.prototype.evaluate = function (lval) {
    var eqResult = lval === this._rval;
    if (!eqResult) {
      var lvalTypeof = typeof lval;
      if (lvalTypeof !== this._rvalTypeof && (lvalTypeof === 'number' || this._rvalTypeof === 'number')) {
        eqResult = (0,_util_number_js__rspack_import_1.numericToNumber)(lval) === this._rvalFloat;
      }
    }
    return this._isEQ ? eqResult : !eqResult;
  };
  return FilterEqualityComparator;
}();
/**
 * [FILTER_COMPARISON_RULE]
 * `lt`|`lte`|`gt`|`gte`:
 * + rval must be a number. And lval will be converted to number (`numericToNumber`) to compare.
 * `eq`:
 * + If same type, compare with `===`.
 * + If there is one number, convert to number (`numericToNumber`) to compare.
 * + Else return `false`.
 * `ne`:
 * + Not `eq`.
 *
 *
 * [SORT_COMPARISON_RULE]
 * All the values are grouped into three categories:
 * + "numeric" (number and numeric string)
 * + "non-numeric-string" (string that excluding numeric string)
 * + "others"
 * "numeric" vs "numeric": values are ordered by number order.
 * "non-numeric-string" vs "non-numeric-string": values are ordered by ES spec (#sec-abstract-relational-comparison).
 * "others" vs "others": do not change order (always return 0).
 * "numeric" vs "non-numeric-string": "non-numeric-string" is treated as "incomparable".
 * "number" vs "others": "others" is treated as "incomparable".
 * "non-numeric-string" vs "others": "others" is treated as "incomparable".
 * "incomparable" will be seen as -Infinity or Infinity (depends on the settings).
 * MEMO:
 *   Non-numeric string sort makes sense when we need to put the items with the same tag together.
 *   But if we support string sort, we still need to avoid the misleading like `'2' > '12'`,
 *   So we treat "numeric-string" sorted by number order rather than string comparison.
 *
 *
 * [CHECK_LIST_OF_THE_RULE_DESIGN]
 * + Do not support string comparison until required. And also need to
 *   avoid the misleading of "2" > "12".
 * + Should avoid the misleading case:
 *   `" 22 " gte "22"` is `true` but `" 22 " eq "22"` is `false`.
 * + JS bad case should be avoided: null <= 0, [] <= 0, ' ' <= 0, ...
 * + Only "numeric" can be converted to comparable number, otherwise converted to NaN.
 *   See `util/number.ts#numericToNumber`.
 *
 * @return If `op` is not `RelationalOperator`, return null;
 */
function createFilterComparator(op, rval) {
  return op === 'eq' || op === 'ne' ? new FilterEqualityComparator(op === 'eq', rval) : (0,zrender_lib_core_util_js__rspack_import_0.hasOwn)(ORDER_COMPARISON_OP_MAP, op) ? new FilterOrderComparator(op, rval) : null;
}
/**
 * @usage
 *  const filterParsed = parseSanitizationFilter(filter);
 *  for( ... ) {
 *      const val = ...;
 *      if (!filter || passesFilter(filterParsed, val)) {
 *          // normal handling
 *      }
 *  }
 */
function parseSanitizationFilter(filter) {
  var filterKey = '';
  var filterG = -Infinity;
  var filterGE = -Infinity;
  var filterL = Infinity;
  var filterLE = Infinity;
  if (filter) {
    if (filter.g != null) {
      filterKey += 'G' + filter.g;
      filterG = filter.g;
    }
    if (filter.ge != null) {
      filterKey += 'GE' + filter.ge;
      filterGE = filter.ge;
    }
    if (filter.l != null) {
      filterKey += 'L' + filter.l;
      filterL = filter.l;
    }
    if (filter.le != null) {
      filterKey += 'LE' + filter.le;
      filterLE = filter.le;
    }
  }
  return {
    key: filterKey,
    g: filterG,
    ge: filterGE,
    l: filterL,
    le: filterLE
  };
}
function passesSanitizationFilter(filterParsed, value) {
  return value > filterParsed.g && value >= filterParsed.ge && value < filterParsed.l && value <= filterParsed.le;
}
// --------- END: Data store sanitization filters ---------
__webpack_require__.d(__webpack_exports__, {
}, {
  SortOrderComparator: SortOrderComparator,
  createFilterComparator: createFilterComparator,
  getRawValueParser: getRawValueParser,
  parseDataValue: parseDataValue,
  parseSanitizationFilter: parseSanitizationFilter,
  passesSanitizationFilter: passesSanitizationFilter
});


}),
59985: (function (__unused_rspack___webpack_module__, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
/* import */ var zrender_lib_core_util_js__rspack_import_0 = __webpack_require__(75275);
/* import */ var _util_types_js__rspack_import_1 = __webpack_require__(40333);

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/


/**
 * AUTO-GENERATED FILE. DO NOT MODIFY.
 */

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/


var DimensionUserOuput = /** @class */function () {
  function DimensionUserOuput(encode, dimRequest) {
    this._encode = encode;
    this._schema = dimRequest;
  }
  DimensionUserOuput.prototype.get = function () {
    return {
      // Do not generate full dimension name until fist used.
      fullDimensions: this._getFullDimensionNames(),
      encode: this._encode
    };
  };
  /**
   * Get all data store dimension names.
   * Theoretically a series data store is defined both by series and used dataset (if any).
   * If some dimensions are omitted for performance reason in `this.dimensions`,
   * the dimension name may not be auto-generated if user does not specify a dimension name.
   * In this case, the dimension name is `null`/`undefined`.
   */
  DimensionUserOuput.prototype._getFullDimensionNames = function () {
    if (!this._cachedDimNames) {
      this._cachedDimNames = this._schema ? this._schema.makeOutputDimensionNames() : [];
    }
    return this._cachedDimNames;
  };
  return DimensionUserOuput;
}();
;
function summarizeDimensions(data, schema) {
  var summary = {};
  var encode = summary.encode = {};
  var notExtraCoordDimMap = (0,zrender_lib_core_util_js__rspack_import_0.createHashMap)();
  var defaultedLabel = [];
  var defaultedTooltip = [];
  var userOutputEncode = {};
  (0,zrender_lib_core_util_js__rspack_import_0.each)(data.dimensions, function (dimName) {
    var dimItem = data.getDimensionInfo(dimName);
    var coordDim = dimItem.coordDim;
    if (coordDim) {
      if (false) {}
      var coordDimIndex = dimItem.coordDimIndex;
      getOrCreateEncodeArr(encode, coordDim)[coordDimIndex] = dimName;
      if (!dimItem.isExtraCoord) {
        notExtraCoordDimMap.set(coordDim, 1);
        // Use the last coord dim (and label friendly) as default label,
        // because when dataset is used, it is hard to guess which dimension
        // can be value dimension. If both show x, y on label is not look good,
        // and conventionally y axis is focused more.
        if (mayLabelDimType(dimItem.type)) {
          defaultedLabel[0] = dimName;
        }
        // User output encode do not contain generated coords.
        // And it only has index. User can use index to retrieve value from the raw item array.
        getOrCreateEncodeArr(userOutputEncode, coordDim)[coordDimIndex] = data.getDimensionIndex(dimItem.name);
      }
      if (dimItem.defaultTooltip) {
        defaultedTooltip.push(dimName);
      }
    }
    _util_types_js__rspack_import_1.VISUAL_DIMENSIONS.each(function (v, otherDim) {
      var encodeArr = getOrCreateEncodeArr(encode, otherDim);
      var dimIndex = dimItem.otherDims[otherDim];
      if (dimIndex != null && dimIndex !== false) {
        encodeArr[dimIndex] = dimItem.name;
      }
    });
  });
  var dataDimsOnCoord = [];
  var encodeFirstDimNotExtra = {};
  notExtraCoordDimMap.each(function (v, coordDim) {
    var dimArr = encode[coordDim];
    encodeFirstDimNotExtra[coordDim] = dimArr[0];
    // Not necessary to remove duplicate, because a data
    // dim canot on more than one coordDim.
    dataDimsOnCoord = dataDimsOnCoord.concat(dimArr);
  });
  summary.dataDimsOnCoord = dataDimsOnCoord;
  summary.dataDimIndicesOnCoord = (0,zrender_lib_core_util_js__rspack_import_0.map)(dataDimsOnCoord, function (dimName) {
    return data.getDimensionInfo(dimName).storeDimIndex;
  });
  summary.encodeFirstDimNotExtra = encodeFirstDimNotExtra;
  var encodeLabel = encode.label;
  // FIXME `encode.label` is not recommended, because formatter cannot be set
  // in this way. Use label.formatter instead. Maybe remove this approach someday.
  if (encodeLabel && encodeLabel.length) {
    defaultedLabel = encodeLabel.slice();
  }
  var encodeTooltip = encode.tooltip;
  if (encodeTooltip && encodeTooltip.length) {
    defaultedTooltip = encodeTooltip.slice();
  } else if (!defaultedTooltip.length) {
    defaultedTooltip = defaultedLabel.slice();
  }
  encode.defaultedLabel = defaultedLabel;
  encode.defaultedTooltip = defaultedTooltip;
  summary.userOutput = new DimensionUserOuput(userOutputEncode, schema);
  return summary;
}
function getOrCreateEncodeArr(encode, dim) {
  if (!encode.hasOwnProperty(dim)) {
    encode[dim] = [];
  }
  return encode[dim];
}
// FIXME:TS should be type `AxisType`
function getDimensionTypeByAxis(axisType) {
  return axisType === 'category' ? 'ordinal' : axisType === 'time' ? 'time' : 'float';
}
function mayLabelDimType(dimType) {
  // In most cases, ordinal and time do not suitable for label.
  // Ordinal info can be displayed on axis. Time is too long.
  return !(dimType === 'ordinal' || dimType === 'time');
}
// function findTheLastDimMayLabel(data) {
//     // Get last value dim
//     let dimensions = data.dimensions.slice();
//     let valueType;
//     let valueDim;
//     while (dimensions.length && (
//         valueDim = dimensions.pop(),
//         valueType = data.getDimensionInfo(valueDim).type,
//         valueType === 'ordinal' || valueType === 'time'
//     )) {} // jshint ignore:line
//     return valueDim;
// }
__webpack_require__.d(__webpack_exports__, {
}, {
  getDimensionTypeByAxis: getDimensionTypeByAxis,
  summarizeDimensions: summarizeDimensions
});


}),
82840: (function (__unused_rspack___webpack_module__, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
/* import */ var zrender_lib_core_util_js__rspack_import_1 = __webpack_require__(75275);
/* import */ var _util_model_js__rspack_import_0 = __webpack_require__(53781);

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/


/**
 * AUTO-GENERATED FILE. DO NOT MODIFY.
 */

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/
/**
 * Link lists and struct (graph or tree)
 */


var inner = (0,_util_model_js__rspack_import_0.makeInner)();
function linkSeriesData(opt) {
  var mainData = opt.mainData;
  var datas = opt.datas;
  if (!datas) {
    datas = {
      main: mainData
    };
    opt.datasAttr = {
      main: 'data'
    };
  }
  opt.datas = opt.mainData = null;
  linkAll(mainData, datas, opt);
  // Porxy data original methods.
  (0,zrender_lib_core_util_js__rspack_import_1.each)(datas, function (data) {
    (0,zrender_lib_core_util_js__rspack_import_1.each)(mainData.TRANSFERABLE_METHODS, function (methodName) {
      data.wrapMethod(methodName, (0,zrender_lib_core_util_js__rspack_import_1.curry)(transferInjection, opt));
    });
  });
  // Beyond transfer, additional features should be added to `cloneShallow`.
  mainData.wrapMethod('cloneShallow', (0,zrender_lib_core_util_js__rspack_import_1.curry)(cloneShallowInjection, opt));
  // Only mainData trigger change, because struct.update may trigger
  // another changable methods, which may bring about dead lock.
  (0,zrender_lib_core_util_js__rspack_import_1.each)(mainData.CHANGABLE_METHODS, function (methodName) {
    mainData.wrapMethod(methodName, (0,zrender_lib_core_util_js__rspack_import_1.curry)(changeInjection, opt));
  });
  // Make sure datas contains mainData.
  (0,zrender_lib_core_util_js__rspack_import_1.assert)(datas[mainData.dataType] === mainData);
}
function transferInjection(opt, res) {
  if (isMainData(this)) {
    // Transfer datas to new main data.
    var datas = (0,zrender_lib_core_util_js__rspack_import_1.extend)({}, inner(this).datas);
    datas[this.dataType] = res;
    linkAll(res, datas, opt);
  } else {
    // Modify the reference in main data to point newData.
    linkSingle(res, this.dataType, inner(this).mainData, opt);
  }
  return res;
}
function changeInjection(opt, res) {
  opt.struct && opt.struct.update();
  return res;
}
function cloneShallowInjection(opt, res) {
  // cloneShallow, which brings about some fragilities, may be inappropriate
  // to be exposed as an API. So for implementation simplicity we can make
  // the restriction that cloneShallow of not-mainData should not be invoked
  // outside, but only be invoked here.
  (0,zrender_lib_core_util_js__rspack_import_1.each)(inner(res).datas, function (data, dataType) {
    data !== res && linkSingle(data.cloneShallow(), dataType, res, opt);
  });
  return res;
}
/**
 * Supplement method to List.
 *
 * @public
 * @param [dataType] If not specified, return mainData.
 */
function getLinkedData(dataType) {
  var mainData = inner(this).mainData;
  return dataType == null || mainData == null ? mainData : inner(mainData).datas[dataType];
}
/**
 * Get list of all linked data
 */
function getLinkedDataAll() {
  var mainData = inner(this).mainData;
  return mainData == null ? [{
    data: mainData
  }] : (0,zrender_lib_core_util_js__rspack_import_1.map)((0,zrender_lib_core_util_js__rspack_import_1.keys)(inner(mainData).datas), function (type) {
    return {
      type: type,
      data: inner(mainData).datas[type]
    };
  });
}
function isMainData(data) {
  return inner(data).mainData === data;
}
function linkAll(mainData, datas, opt) {
  inner(mainData).datas = {};
  (0,zrender_lib_core_util_js__rspack_import_1.each)(datas, function (data, dataType) {
    linkSingle(data, dataType, mainData, opt);
  });
}
function linkSingle(data, dataType, mainData, opt) {
  inner(mainData).datas[dataType] = data;
  inner(data).mainData = mainData;
  data.dataType = dataType;
  if (opt.struct) {
    data[opt.structAttr] = opt.struct;
    opt.struct[opt.datasAttr[dataType]] = data;
  }
  // Supplement method.
  data.getLinkedData = getLinkedData;
  data.getLinkedDataAll = getLinkedDataAll;
}
/* export default */ __webpack_exports__["default"] = (linkSeriesData);

}),
44872: (function (__unused_rspack___webpack_module__, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
/* import */ var _util_model_js__rspack_import_0 = __webpack_require__(53781);
/* import */ var zrender_lib_core_util_js__rspack_import_1 = __webpack_require__(75275);
/* import */ var _util_types_js__rspack_import_2 = __webpack_require__(40333);

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/


/**
 * AUTO-GENERATED FILE. DO NOT MODIFY.
 */

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/



// The result of `guessOrdinal`.
var BE_ORDINAL = {
  Must: 1,
  Might: 2,
  Not: 3 // Other cases
};
var innerGlobalModel = (0,_util_model_js__rspack_import_0.makeInner)();
/**
 * MUST be called before mergeOption of all series.
 */
function resetSourceDefaulter(ecModel) {
  // `datasetMap` is used to make default encode.
  innerGlobalModel(ecModel).datasetMap = (0,zrender_lib_core_util_js__rspack_import_1.createHashMap)();
}
/**
 * [The strategy of the arrengment of data dimensions for dataset]:
 * "value way": all axes are non-category axes. So series one by one take
 *     several (the number is coordSysDims.length) dimensions from dataset.
 *     The result of data arrengment of data dimensions like:
 *     | ser0_x | ser0_y | ser1_x | ser1_y | ser2_x | ser2_y |
 * "category way": at least one axis is category axis. So the the first data
 *     dimension is always mapped to the first category axis and shared by
 *     all of the series. The other data dimensions are taken by series like
 *     "value way" does.
 *     The result of data arrengment of data dimensions like:
 *     | ser_shared_x | ser0_y | ser1_y | ser2_y |
 *
 * @return encode Never be `null/undefined`.
 */
function makeSeriesEncodeForAxisCoordSys(coordDimensions, seriesModel, source) {
  var encode = {};
  var datasetModel = querySeriesUpstreamDatasetModel(seriesModel);
  // Currently only make default when using dataset, util more reqirements occur.
  if (!datasetModel || !coordDimensions) {
    return encode;
  }
  var encodeItemName = [];
  var encodeSeriesName = [];
  var ecModel = seriesModel.ecModel;
  var datasetMap = innerGlobalModel(ecModel).datasetMap;
  var key = datasetModel.uid + '_' + source.seriesLayoutBy;
  var baseCategoryDimIndex;
  var categoryWayValueDimStart;
  coordDimensions = coordDimensions.slice();
  (0,zrender_lib_core_util_js__rspack_import_1.each)(coordDimensions, function (coordDimInfoLoose, coordDimIdx) {
    var coordDimInfo = (0,zrender_lib_core_util_js__rspack_import_1.isObject)(coordDimInfoLoose) ? coordDimInfoLoose : coordDimensions[coordDimIdx] = {
      name: coordDimInfoLoose
    };
    if (coordDimInfo.type === 'ordinal' && baseCategoryDimIndex == null) {
      baseCategoryDimIndex = coordDimIdx;
      categoryWayValueDimStart = getDataDimCountOnCoordDim(coordDimInfo);
    }
    encode[coordDimInfo.name] = [];
  });
  var datasetRecord = datasetMap.get(key) || datasetMap.set(key, {
    categoryWayDim: categoryWayValueDimStart,
    valueWayDim: 0
  });
  // TODO
  // Auto detect first time axis and do arrangement.
  (0,zrender_lib_core_util_js__rspack_import_1.each)(coordDimensions, function (coordDimInfo, coordDimIdx) {
    var coordDimName = coordDimInfo.name;
    var count = getDataDimCountOnCoordDim(coordDimInfo);
    // In value way.
    if (baseCategoryDimIndex == null) {
      var start = datasetRecord.valueWayDim;
      pushDim(encode[coordDimName], start, count);
      pushDim(encodeSeriesName, start, count);
      datasetRecord.valueWayDim += count;
      // ??? TODO give a better default series name rule?
      // especially when encode x y specified.
      // consider: when multiple series share one dimension
      // category axis, series name should better use
      // the other dimension name. On the other hand, use
      // both dimensions name.
    }
    // In category way, the first category axis.
    else if (baseCategoryDimIndex === coordDimIdx) {
      pushDim(encode[coordDimName], 0, count);
      pushDim(encodeItemName, 0, count);
    }
    // In category way, the other axis.
    else {
      var start = datasetRecord.categoryWayDim;
      pushDim(encode[coordDimName], start, count);
      pushDim(encodeSeriesName, start, count);
      datasetRecord.categoryWayDim += count;
    }
  });
  function pushDim(dimIdxArr, idxFrom, idxCount) {
    for (var i = 0; i < idxCount; i++) {
      dimIdxArr.push(idxFrom + i);
    }
  }
  function getDataDimCountOnCoordDim(coordDimInfo) {
    var dimsDef = coordDimInfo.dimsDef;
    return dimsDef ? dimsDef.length : 1;
  }
  encodeItemName.length && (encode.itemName = encodeItemName);
  encodeSeriesName.length && (encode.seriesName = encodeSeriesName);
  return encode;
}
/**
 * Work for data like [{name: ..., value: ...}, ...].
 *
 * @return encode Never be `null/undefined`.
 */
function makeSeriesEncodeForNameBased(seriesModel, source, dimCount) {
  var encode = {};
  var datasetModel = querySeriesUpstreamDatasetModel(seriesModel);
  // Currently only make default when using dataset, util more reqirements occur.
  if (!datasetModel) {
    return encode;
  }
  var sourceFormat = source.sourceFormat;
  var dimensionsDefine = source.dimensionsDefine;
  var potentialNameDimIndex;
  if (sourceFormat === _util_types_js__rspack_import_2.SOURCE_FORMAT_OBJECT_ROWS || sourceFormat === _util_types_js__rspack_import_2.SOURCE_FORMAT_KEYED_COLUMNS) {
    (0,zrender_lib_core_util_js__rspack_import_1.each)(dimensionsDefine, function (dim, idx) {
      if (((0,zrender_lib_core_util_js__rspack_import_1.isObject)(dim) ? dim.name : dim) === 'name') {
        potentialNameDimIndex = idx;
      }
    });
  }
  var idxResult = function () {
    var idxRes0 = {};
    var idxRes1 = {};
    var guessRecords = [];
    // 5 is an experience value.
    for (var i = 0, len = Math.min(5, dimCount); i < len; i++) {
      var guessResult = doGuessOrdinal(source.data, sourceFormat, source.seriesLayoutBy, dimensionsDefine, source.startIndex, i);
      guessRecords.push(guessResult);
      var isPureNumber = guessResult === BE_ORDINAL.Not;
      // [Strategy of idxRes0]: find the first BE_ORDINAL.Not as the value dim,
      // and then find a name dim with the priority:
      // "BE_ORDINAL.Might|BE_ORDINAL.Must" > "other dim" > "the value dim itself".
      if (isPureNumber && idxRes0.v == null && i !== potentialNameDimIndex) {
        idxRes0.v = i;
      }
      if (idxRes0.n == null || idxRes0.n === idxRes0.v || !isPureNumber && guessRecords[idxRes0.n] === BE_ORDINAL.Not) {
        idxRes0.n = i;
      }
      if (fulfilled(idxRes0) && guessRecords[idxRes0.n] !== BE_ORDINAL.Not) {
        return idxRes0;
      }
      // [Strategy of idxRes1]: if idxRes0 not satisfied (that is, no BE_ORDINAL.Not),
      // find the first BE_ORDINAL.Might as the value dim,
      // and then find a name dim with the priority:
      // "other dim" > "the value dim itself".
      // That is for backward compat: number-like (e.g., `'3'`, `'55'`) can be
      // treated as number.
      if (!isPureNumber) {
        if (guessResult === BE_ORDINAL.Might && idxRes1.v == null && i !== potentialNameDimIndex) {
          idxRes1.v = i;
        }
        if (idxRes1.n == null || idxRes1.n === idxRes1.v) {
          idxRes1.n = i;
        }
      }
    }
    function fulfilled(idxResult) {
      return idxResult.v != null && idxResult.n != null;
    }
    return fulfilled(idxRes0) ? idxRes0 : fulfilled(idxRes1) ? idxRes1 : null;
  }();
  if (idxResult) {
    encode.value = [idxResult.v];
    // `potentialNameDimIndex` has highest priority.
    var nameDimIndex = potentialNameDimIndex != null ? potentialNameDimIndex : idxResult.n;
    // By default, label uses itemName in charts.
    // So we don't set encodeLabel here.
    encode.itemName = [nameDimIndex];
    encode.seriesName = [nameDimIndex];
  }
  return encode;
}
/**
 * @return If return null/undefined, indicate that should not use datasetModel.
 */
function querySeriesUpstreamDatasetModel(seriesModel) {
  // Caution: consider the scenario:
  // A dataset is declared and a series is not expected to use the dataset,
  // and at the beginning `setOption({series: { noData })` (just prepare other
  // option but no data), then `setOption({series: {data: [...]}); In this case,
  // the user should set an empty array to avoid that dataset is used by default.
  var thisData = seriesModel.get('data', true);
  if (!thisData) {
    return (0,_util_model_js__rspack_import_0.queryReferringComponents)(seriesModel.ecModel, 'dataset', {
      index: seriesModel.get('datasetIndex', true),
      id: seriesModel.get('datasetId', true)
    }, _util_model_js__rspack_import_0.SINGLE_REFERRING).models[0];
  }
}
/**
 * @return Always return an array event empty.
 */
function queryDatasetUpstreamDatasetModels(datasetModel) {
  // Only these attributes declared, we by default reference to `datasetIndex: 0`.
  // Otherwise, no reference.
  if (!datasetModel.get('transform', true) && !datasetModel.get('fromTransformResult', true)) {
    return [];
  }
  return (0,_util_model_js__rspack_import_0.queryReferringComponents)(datasetModel.ecModel, 'dataset', {
    index: datasetModel.get('fromDatasetIndex', true),
    id: datasetModel.get('fromDatasetId', true)
  }, _util_model_js__rspack_import_0.SINGLE_REFERRING).models;
}
/**
 * The rule should not be complex, otherwise user might not
 * be able to known where the data is wrong.
 * The code is ugly, but how to make it neat?
 */
function guessOrdinal(source, dimIndex) {
  return doGuessOrdinal(source.data, source.sourceFormat, source.seriesLayoutBy, source.dimensionsDefine, source.startIndex, dimIndex);
}
// dimIndex may be overflow source data.
// return {BE_ORDINAL}
function doGuessOrdinal(data, sourceFormat, seriesLayoutBy, dimensionsDefine, startIndex, dimIndex) {
  var result;
  // Experience value.
  var maxLoop = 5;
  if ((0,zrender_lib_core_util_js__rspack_import_1.isTypedArray)(data)) {
    return BE_ORDINAL.Not;
  }
  // When sourceType is 'objectRows' or 'keyedColumns', dimensionsDefine
  // always exists in source.
  var dimName;
  var dimType;
  if (dimensionsDefine) {
    var dimDefItem = dimensionsDefine[dimIndex];
    if ((0,zrender_lib_core_util_js__rspack_import_1.isObject)(dimDefItem)) {
      dimName = dimDefItem.name;
      dimType = dimDefItem.type;
    } else if ((0,zrender_lib_core_util_js__rspack_import_1.isString)(dimDefItem)) {
      dimName = dimDefItem;
    }
  }
  if (dimType != null) {
    return dimType === 'ordinal' ? BE_ORDINAL.Must : BE_ORDINAL.Not;
  }
  if (sourceFormat === _util_types_js__rspack_import_2.SOURCE_FORMAT_ARRAY_ROWS) {
    var dataArrayRows = data;
    if (seriesLayoutBy === _util_types_js__rspack_import_2.SERIES_LAYOUT_BY_ROW) {
      var sample = dataArrayRows[dimIndex];
      for (var i = 0; i < (sample || []).length && i < maxLoop; i++) {
        if ((result = detectValue(sample[startIndex + i])) != null) {
          return result;
        }
      }
    } else {
      for (var i = 0; i < dataArrayRows.length && i < maxLoop; i++) {
        var row = dataArrayRows[startIndex + i];
        if (row && (result = detectValue(row[dimIndex])) != null) {
          return result;
        }
      }
    }
  } else if (sourceFormat === _util_types_js__rspack_import_2.SOURCE_FORMAT_OBJECT_ROWS) {
    var dataObjectRows = data;
    if (!dimName) {
      return BE_ORDINAL.Not;
    }
    for (var i = 0; i < dataObjectRows.length && i < maxLoop; i++) {
      var item = dataObjectRows[i];
      if (item && (result = detectValue(item[dimName])) != null) {
        return result;
      }
    }
  } else if (sourceFormat === _util_types_js__rspack_import_2.SOURCE_FORMAT_KEYED_COLUMNS) {
    var dataKeyedColumns = data;
    if (!dimName) {
      return BE_ORDINAL.Not;
    }
    var sample = dataKeyedColumns[dimName];
    if (!sample || (0,zrender_lib_core_util_js__rspack_import_1.isTypedArray)(sample)) {
      return BE_ORDINAL.Not;
    }
    for (var i = 0; i < sample.length && i < maxLoop; i++) {
      if ((result = detectValue(sample[i])) != null) {
        return result;
      }
    }
  } else if (sourceFormat === _util_types_js__rspack_import_2.SOURCE_FORMAT_ORIGINAL) {
    var dataOriginal = data;
    for (var i = 0; i < dataOriginal.length && i < maxLoop; i++) {
      var item = dataOriginal[i];
      var val = (0,_util_model_js__rspack_import_0.getDataItemValue)(item);
      if (!(0,zrender_lib_core_util_js__rspack_import_1.isArray)(val)) {
        return BE_ORDINAL.Not;
      }
      if ((result = detectValue(val[dimIndex])) != null) {
        return result;
      }
    }
  }
  function detectValue(val) {
    var beStr = (0,zrender_lib_core_util_js__rspack_import_1.isString)(val);
    // Consider usage convenience, '1', '2' will be treated as "number".
    // `Number('')` (or any whitespace) is `0`.
    // `Number(val)` prevents error for BigInt.
    if (val != null && isFinite(Number(val)) && val !== '') {
      return beStr ? BE_ORDINAL.Might : BE_ORDINAL.Not;
    } else if (beStr && val !== '-') {
      return BE_ORDINAL.Must;
    }
  }
  return BE_ORDINAL.Not;
}
__webpack_require__.d(__webpack_exports__, {
}, {
  BE_ORDINAL: BE_ORDINAL,
  guessOrdinal: guessOrdinal,
  makeSeriesEncodeForAxisCoordSys: makeSeriesEncodeForAxisCoordSys,
  makeSeriesEncodeForNameBased: makeSeriesEncodeForNameBased,
  queryDatasetUpstreamDatasetModels: queryDatasetUpstreamDatasetModels,
  querySeriesUpstreamDatasetModel: querySeriesUpstreamDatasetModel,
  resetSourceDefaulter: resetSourceDefaulter
});


}),
92537: (function (__unused_rspack___webpack_module__, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
/* import */ var zrender_lib_core_util_js__rspack_import_0 = __webpack_require__(75275);
/* import */ var _Source_js__rspack_import_2 = __webpack_require__(17043);
/* import */ var _util_types_js__rspack_import_1 = __webpack_require__(40333);
/* import */ var _sourceHelper_js__rspack_import_6 = __webpack_require__(44872);
/* import */ var _transform_js__rspack_import_3 = __webpack_require__(40821);
/* import */ var _DataStore_js__rspack_import_4 = __webpack_require__(93349);
/* import */ var _dataProvider_js__rspack_import_5 = __webpack_require__(13988);

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/


/**
 * AUTO-GENERATED FILE. DO NOT MODIFY.
 */

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/







/**
 * [REQUIREMENT_MEMO]:
 * (0) `metaRawOption` means `dimensions`/`sourceHeader`/`seriesLayoutBy` in raw option.
 * (1) Keep support the feature: `metaRawOption` can be specified both on `series` and
 * `root-dataset`. Them on `series` has higher priority.
 * (2) Do not support to set `metaRawOption` on a `non-root-dataset`, because it might
 * confuse users: whether those props indicate how to visit the upstream source or visit
 * the transform result source, and some transforms has nothing to do with these props,
 * and some transforms might have multiple upstream.
 * (3) Transforms should specify `metaRawOption` in each output, just like they can be
 * declared in `root-dataset`.
 * (4) At present only support visit source in `SERIES_LAYOUT_BY_COLUMN` in transforms.
 * That is for reducing complexity in transforms.
 * PENDING: Whether to provide transposition transform?
 *
 * [IMPLEMENTAION_MEMO]:
 * "sourceVisitConfig" are calculated from `metaRawOption` and `data`.
 * They will not be calculated until `source` is about to be visited (to prevent from
 * duplicate calcuation). `source` is visited only in series and input to transforms.
 *
 * [DIMENSION_INHERIT_RULE]:
 * By default the dimensions are inherited from ancestors, unless a transform return
 * a new dimensions definition.
 * Consider the case:
 * ```js
 * dataset: [{
 *     source: [ ['Product', 'Sales', 'Prise'], ['Cookies', 321, 44.21], ...]
 * }, {
 *     transform: { type: 'filter', ... }
 * }]
 * dataset: [{
 *     dimension: ['Product', 'Sales', 'Prise'],
 *     source: [ ['Cookies', 321, 44.21], ...]
 * }, {
 *     transform: { type: 'filter', ... }
 * }]
 * ```
 * The two types of option should have the same behavior after transform.
 *
 *
 * [SCENARIO]:
 * (1) Provide source data directly:
 * ```js
 * series: {
 *     encode: {...},
 *     dimensions: [...]
 *     seriesLayoutBy: 'row',
 *     data: [[...]]
 * }
 * ```
 * (2) Series refer to dataset.
 * ```js
 * series: [{
 *     encode: {...}
 *     // Ignore datasetIndex means `datasetIndex: 0`
 *     // and the dimensions defination in dataset is used
 * }, {
 *     encode: {...},
 *     seriesLayoutBy: 'column',
 *     datasetIndex: 1
 * }]
 * ```
 * (3) dataset transform
 * ```js
 * dataset: [{
 *     source: [...]
 * }, {
 *     source: [...]
 * }, {
 *     // By default from 0.
 *     transform: { type: 'filter', config: {...} }
 * }, {
 *     // Piped.
 *     transform: [
 *         { type: 'filter', config: {...} },
 *         { type: 'sort', config: {...} }
 *     ]
 * }, {
 *     id: 'regressionData',
 *     fromDatasetIndex: 1,
 *     // Third-party transform
 *     transform: { type: 'ecStat:regression', config: {...} }
 * }, {
 *     // retrieve the extra result.
 *     id: 'regressionFormula',
 *     fromDatasetId: 'regressionData',
 *     fromTransformResult: 1
 * }]
 * ```
 */
var SourceManager = /** @class */function () {
  function SourceManager(sourceHost) {
    // Cached source. Do not repeat calculating if not dirty.
    this._sourceList = [];
    this._storeList = [];
    // version sign of each upstream source manager.
    this._upstreamSignList = [];
    this._versionSignBase = 0;
    this._dirty = true;
    this._sourceHost = sourceHost;
  }
  /**
   * Mark dirty.
   */
  SourceManager.prototype.dirty = function () {
    this._setLocalSource([], []);
    this._storeList = [];
    this._dirty = true;
  };
  SourceManager.prototype._setLocalSource = function (sourceList, upstreamSignList) {
    this._sourceList = sourceList;
    this._upstreamSignList = upstreamSignList;
    this._versionSignBase++;
    if (this._versionSignBase > 9e10) {
      this._versionSignBase = 0;
    }
  };
  /**
   * For detecting whether the upstream source is dirty, so that
   * the local cached source (in `_sourceList`) should be discarded.
   */
  SourceManager.prototype._getVersionSign = function () {
    return this._sourceHost.uid + '_' + this._versionSignBase;
  };
  /**
   * Always return a source instance. Otherwise throw error.
   */
  SourceManager.prototype.prepareSource = function () {
    // For the case that call `setOption` multiple time but no data changed,
    // cache the result source to prevent from repeating transform.
    if (this._isDirty()) {
      this._createSource();
      this._dirty = false;
    }
  };
  SourceManager.prototype._createSource = function () {
    this._setLocalSource([], []);
    var sourceHost = this._sourceHost;
    var upSourceMgrList = this._getUpstreamSourceManagers();
    var hasUpstream = !!upSourceMgrList.length;
    var resultSourceList;
    var upstreamSignList;
    if (isSeries(sourceHost)) {
      var seriesModel = sourceHost;
      var data = void 0;
      var sourceFormat = void 0;
      var upSource = void 0;
      // Has upstream dataset
      if (hasUpstream) {
        var upSourceMgr = upSourceMgrList[0];
        upSourceMgr.prepareSource();
        upSource = upSourceMgr.getSource();
        data = upSource.data;
        sourceFormat = upSource.sourceFormat;
        upstreamSignList = [upSourceMgr._getVersionSign()];
      }
      // Series data is from own.
      else {
        data = seriesModel.get('data', true);
        sourceFormat = (0,zrender_lib_core_util_js__rspack_import_0.isTypedArray)(data) ? _util_types_js__rspack_import_1.SOURCE_FORMAT_TYPED_ARRAY : _util_types_js__rspack_import_1.SOURCE_FORMAT_ORIGINAL;
        upstreamSignList = [];
      }
      // See [REQUIREMENT_MEMO], merge settings on series and parent dataset if it is root.
      var newMetaRawOption = this._getSourceMetaRawOption() || {};
      var upMetaRawOption = upSource && upSource.metaRawOption || {};
      var seriesLayoutBy = (0,zrender_lib_core_util_js__rspack_import_0.retrieve2)(newMetaRawOption.seriesLayoutBy, upMetaRawOption.seriesLayoutBy) || null;
      var sourceHeader = (0,zrender_lib_core_util_js__rspack_import_0.retrieve2)(newMetaRawOption.sourceHeader, upMetaRawOption.sourceHeader);
      // Note here we should not use `upSource.dimensionsDefine`. Consider the case:
      // `upSource.dimensionsDefine` is detected by `seriesLayoutBy: 'column'`,
      // but series need `seriesLayoutBy: 'row'`.
      var dimensions = (0,zrender_lib_core_util_js__rspack_import_0.retrieve2)(newMetaRawOption.dimensions, upMetaRawOption.dimensions);
      // We share source with dataset as much as possible
      // to avoid extra memory cost of high dimensional data.
      var needsCreateSource = seriesLayoutBy !== upMetaRawOption.seriesLayoutBy || !!sourceHeader !== !!upMetaRawOption.sourceHeader || dimensions;
      resultSourceList = needsCreateSource ? [(0,_Source_js__rspack_import_2.createSource)(data, {
        seriesLayoutBy: seriesLayoutBy,
        sourceHeader: sourceHeader,
        dimensions: dimensions
      }, sourceFormat)] : [];
    } else {
      var datasetModel = sourceHost;
      // Has upstream dataset.
      if (hasUpstream) {
        var result = this._applyTransform(upSourceMgrList);
        resultSourceList = result.sourceList;
        upstreamSignList = result.upstreamSignList;
      }
      // Is root dataset.
      else {
        var sourceData = datasetModel.get('source', true);
        resultSourceList = [(0,_Source_js__rspack_import_2.createSource)(sourceData, this._getSourceMetaRawOption(), null)];
        upstreamSignList = [];
      }
    }
    if (false) {}
    this._setLocalSource(resultSourceList, upstreamSignList);
  };
  SourceManager.prototype._applyTransform = function (upMgrList) {
    var datasetModel = this._sourceHost;
    var transformOption = datasetModel.get('transform', true);
    var fromTransformResult = datasetModel.get('fromTransformResult', true);
    if (false) {}
    if (fromTransformResult != null) {
      var errMsg = '';
      if (upMgrList.length !== 1) {
        if (false) {}
        doThrow(errMsg);
      }
    }
    var sourceList;
    var upSourceList = [];
    var upstreamSignList = [];
    (0,zrender_lib_core_util_js__rspack_import_0.each)(upMgrList, function (upMgr) {
      upMgr.prepareSource();
      var upSource = upMgr.getSource(fromTransformResult || 0);
      var errMsg = '';
      if (fromTransformResult != null && !upSource) {
        if (false) {}
        doThrow(errMsg);
      }
      upSourceList.push(upSource);
      upstreamSignList.push(upMgr._getVersionSign());
    });
    if (transformOption) {
      sourceList = (0,_transform_js__rspack_import_3.applyDataTransform)(transformOption, upSourceList, {
        datasetIndex: datasetModel.componentIndex
      });
    } else if (fromTransformResult != null) {
      sourceList = [(0,_Source_js__rspack_import_2.cloneSourceShallow)(upSourceList[0])];
    }
    return {
      sourceList: sourceList,
      upstreamSignList: upstreamSignList
    };
  };
  SourceManager.prototype._isDirty = function () {
    if (this._dirty) {
      return true;
    }
    // All sourceList is from the some upstream.
    var upSourceMgrList = this._getUpstreamSourceManagers();
    for (var i = 0; i < upSourceMgrList.length; i++) {
      var upSrcMgr = upSourceMgrList[i];
      if (
      // Consider the case that there is ancestor diry, call it recursively.
      // The performance is probably not an issue because usually the chain is not long.
      upSrcMgr._isDirty() || this._upstreamSignList[i] !== upSrcMgr._getVersionSign()) {
        return true;
      }
    }
  };
  /**
   * @param sourceIndex By default 0, means "main source".
   *                    In most cases there is only one source.
   */
  SourceManager.prototype.getSource = function (sourceIndex) {
    sourceIndex = sourceIndex || 0;
    var source = this._sourceList[sourceIndex];
    if (!source) {
      // Series may share source instance with dataset.
      var upSourceMgrList = this._getUpstreamSourceManagers();
      return upSourceMgrList[0] && upSourceMgrList[0].getSource(sourceIndex);
    }
    return source;
  };
  /**
   *
   * Get a data store which can be shared across series.
   * Only available for series.
   *
   * @param seriesDimRequest Dimensions that are generated in series.
   *        Should have been sorted by `storeDimIndex` asc.
   */
  SourceManager.prototype.getSharedDataStore = function (seriesDimRequest) {
    if (false) {}
    var schema = seriesDimRequest.makeStoreSchema();
    return this._innerGetDataStore(schema.dimensions, seriesDimRequest.source, schema.hash);
  };
  SourceManager.prototype._innerGetDataStore = function (storeDims, seriesSource, sourceReadKey) {
    // TODO Can use other sourceIndex?
    var sourceIndex = 0;
    var storeList = this._storeList;
    var cachedStoreMap = storeList[sourceIndex];
    if (!cachedStoreMap) {
      cachedStoreMap = storeList[sourceIndex] = {};
    }
    var cachedStore = cachedStoreMap[sourceReadKey];
    if (!cachedStore) {
      var upSourceMgr = this._getUpstreamSourceManagers()[0];
      if (isSeries(this._sourceHost) && upSourceMgr) {
        cachedStore = upSourceMgr._innerGetDataStore(storeDims, seriesSource, sourceReadKey);
      } else {
        cachedStore = new _DataStore_js__rspack_import_4["default"]();
        // Always create store from source of series.
        cachedStore.initData(new _dataProvider_js__rspack_import_5.DefaultDataProvider(seriesSource, storeDims.length), storeDims);
      }
      cachedStoreMap[sourceReadKey] = cachedStore;
    }
    return cachedStore;
  };
  /**
   * PENDING: Is it fast enough?
   * If no upstream, return empty array.
   */
  SourceManager.prototype._getUpstreamSourceManagers = function () {
    // Always get the relationship from the raw option.
    // Do not cache the link of the dependency graph, so that
    // there is no need to update them when change happens.
    var sourceHost = this._sourceHost;
    if (isSeries(sourceHost)) {
      var datasetModel = (0,_sourceHelper_js__rspack_import_6.querySeriesUpstreamDatasetModel)(sourceHost);
      return !datasetModel ? [] : [datasetModel.getSourceManager()];
    } else {
      return (0,zrender_lib_core_util_js__rspack_import_0.map)((0,_sourceHelper_js__rspack_import_6.queryDatasetUpstreamDatasetModels)(sourceHost), function (datasetModel) {
        return datasetModel.getSourceManager();
      });
    }
  };
  SourceManager.prototype._getSourceMetaRawOption = function () {
    var sourceHost = this._sourceHost;
    var seriesLayoutBy;
    var sourceHeader;
    var dimensions;
    if (isSeries(sourceHost)) {
      seriesLayoutBy = sourceHost.get('seriesLayoutBy', true);
      sourceHeader = sourceHost.get('sourceHeader', true);
      dimensions = sourceHost.get('dimensions', true);
    }
    // See [REQUIREMENT_MEMO], `non-root-dataset` do not support them.
    else if (!this._getUpstreamSourceManagers().length) {
      var model = sourceHost;
      seriesLayoutBy = model.get('seriesLayoutBy', true);
      sourceHeader = model.get('sourceHeader', true);
      dimensions = model.get('dimensions', true);
    }
    return {
      seriesLayoutBy: seriesLayoutBy,
      sourceHeader: sourceHeader,
      dimensions: dimensions
    };
  };
  return SourceManager;
}();

// Call this method after `super.init` and `super.mergeOption` to
// disable the transform merge, but do not disable transform clone from rawOption.
function disableTransformOptionMerge(datasetModel) {
  var transformOption = datasetModel.option.transform;
  transformOption && (0,zrender_lib_core_util_js__rspack_import_0.setAsPrimitive)(datasetModel.option.transform);
}
function isSeries(sourceHost) {
  // Avoid circular dependency with Series.ts
  return sourceHost.mainType === 'series';
}
function doThrow(errMsg) {
  throw new Error(errMsg);
}
__webpack_require__.d(__webpack_exports__, {
}, {
  SourceManager: SourceManager,
  disableTransformOptionMerge: disableTransformOptionMerge
});


}),
40821: (function (__unused_rspack___webpack_module__, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
/* import */ var _util_types_js__rspack_import_1 = __webpack_require__(40333);
/* import */ var _util_model_js__rspack_import_5 = __webpack_require__(53781);
/* import */ var zrender_lib_core_util_js__rspack_import_3 = __webpack_require__(75275);
/* import */ var _dataProvider_js__rspack_import_4 = __webpack_require__(13988);
/* import */ var _dataValueHelper_js__rspack_import_0 = __webpack_require__(94276);
/* import */ var _util_log_js__rspack_import_2 = __webpack_require__(44002);
/* import */ var _Source_js__rspack_import_6 = __webpack_require__(17043);

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/


/**
 * AUTO-GENERATED FILE. DO NOT MODIFY.
 */

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/







/**
 * TODO: disable writable.
 * This structure will be exposed to users.
 */
var ExternalSource = /** @class */function () {
  function ExternalSource() {}
  ExternalSource.prototype.getRawData = function () {
    // Only built-in transform available.
    throw new Error('not supported');
  };
  ExternalSource.prototype.getRawDataItem = function (dataIndex) {
    // Only built-in transform available.
    throw new Error('not supported');
  };
  ExternalSource.prototype.cloneRawData = function () {
    return;
  };
  /**
   * @return If dimension not found, return null/undefined.
   */
  ExternalSource.prototype.getDimensionInfo = function (dim) {
    return;
  };
  /**
   * dimensions defined if and only if either:
   * (a) dataset.dimensions are declared.
   * (b) dataset data include dimensions definitions in data (detected or via specified `sourceHeader`).
   * If dimensions are defined, `dimensionInfoAll` is corresponding to
   * the defined dimensions.
   * Otherwise, `dimensionInfoAll` is determined by data columns.
   * @return Always return an array (even empty array).
   */
  ExternalSource.prototype.cloneAllDimensionInfo = function () {
    return;
  };
  ExternalSource.prototype.count = function () {
    return;
  };
  /**
   * Only support by dimension index.
   * No need to support by dimension name in transform function,
   * because transform function is not case-specific, no need to use name literally.
   */
  ExternalSource.prototype.retrieveValue = function (dataIndex, dimIndex) {
    return;
  };
  ExternalSource.prototype.retrieveValueFromItem = function (dataItem, dimIndex) {
    return;
  };
  ExternalSource.prototype.convertValue = function (rawVal, dimInfo) {
    return (0,_dataValueHelper_js__rspack_import_0.parseDataValue)(rawVal, dimInfo);
  };
  return ExternalSource;
}();

function createExternalSource(internalSource, externalTransform) {
  var extSource = new ExternalSource();
  var data = internalSource.data;
  var sourceFormat = extSource.sourceFormat = internalSource.sourceFormat;
  var sourceHeaderCount = internalSource.startIndex;
  var errMsg = '';
  if (internalSource.seriesLayoutBy !== _util_types_js__rspack_import_1.SERIES_LAYOUT_BY_COLUMN) {
    // For the logic simplicity in transformer, only 'culumn' is
    // supported in data transform. Otherwise, the `dimensionsDefine`
    // might be detected by 'row', which probably confuses users.
    if (false) {}
    (0,_util_log_js__rspack_import_2.throwError)(errMsg);
  }
  // [MEMO]
  // Create a new dimensions structure for exposing.
  // Do not expose all dimension info to users directly.
  // Because the dimension is probably auto detected from data and not might reliable.
  // Should not lead the transformers to think that is reliable and return it.
  // See [DIMENSION_INHERIT_RULE] in `sourceManager.ts`.
  var dimensions = [];
  var dimsByName = {};
  var dimsDef = internalSource.dimensionsDefine;
  if (dimsDef) {
    (0,zrender_lib_core_util_js__rspack_import_3.each)(dimsDef, function (dimDef, idx) {
      var name = dimDef.name;
      var dimDefExt = {
        index: idx,
        name: name,
        displayName: dimDef.displayName
      };
      dimensions.push(dimDefExt);
      // Users probably do not specify dimension name. For simplicity, data transform
      // does not generate dimension name.
      if (name != null) {
        // Dimension name should not be duplicated.
        // For simplicity, data transform forbids name duplication, do not generate
        // new name like module `completeDimensions.ts` did, but just tell users.
        var errMsg_1 = '';
        if ((0,zrender_lib_core_util_js__rspack_import_3.hasOwn)(dimsByName, name)) {
          if (false) {}
          (0,_util_log_js__rspack_import_2.throwError)(errMsg_1);
        }
        dimsByName[name] = dimDefExt;
      }
    });
  }
  // If dimension definitions are not defined and can not be detected.
  // e.g., pure data `[[11, 22], ...]`.
  else {
    for (var i = 0; i < internalSource.dimensionsDetectedCount || 0; i++) {
      // Do not generete name or anything others. The consequence process in
      // `transform` or `series` probably have there own name generation strategry.
      dimensions.push({
        index: i
      });
    }
  }
  // Implement public methods:
  var rawItemGetter = (0,_dataProvider_js__rspack_import_4.getRawSourceItemGetter)(sourceFormat, _util_types_js__rspack_import_1.SERIES_LAYOUT_BY_COLUMN);
  if (externalTransform.__isBuiltIn) {
    extSource.getRawDataItem = function (dataIndex) {
      return rawItemGetter(data, sourceHeaderCount, dimensions, dataIndex);
    };
    extSource.getRawData = (0,zrender_lib_core_util_js__rspack_import_3.bind)(getRawData, null, internalSource);
  }
  extSource.cloneRawData = (0,zrender_lib_core_util_js__rspack_import_3.bind)(cloneRawData, null, internalSource);
  var rawCounter = (0,_dataProvider_js__rspack_import_4.getRawSourceDataCounter)(sourceFormat, _util_types_js__rspack_import_1.SERIES_LAYOUT_BY_COLUMN);
  extSource.count = (0,zrender_lib_core_util_js__rspack_import_3.bind)(rawCounter, null, data, sourceHeaderCount, dimensions);
  var rawValueGetter = (0,_dataProvider_js__rspack_import_4.getRawSourceValueGetter)(sourceFormat);
  extSource.retrieveValue = function (dataIndex, dimIndex) {
    var rawItem = rawItemGetter(data, sourceHeaderCount, dimensions, dataIndex);
    return retrieveValueFromItem(rawItem, dimIndex);
  };
  var retrieveValueFromItem = extSource.retrieveValueFromItem = function (dataItem, dimIndex) {
    if (dataItem == null) {
      return;
    }
    var dimDef = dimensions[dimIndex];
    // When `dimIndex` is `null`, `rawValueGetter` return the whole item.
    if (dimDef) {
      return rawValueGetter(dataItem, dimIndex, dimDef.name);
    }
  };
  extSource.getDimensionInfo = (0,zrender_lib_core_util_js__rspack_import_3.bind)(getDimensionInfo, null, dimensions, dimsByName);
  extSource.cloneAllDimensionInfo = (0,zrender_lib_core_util_js__rspack_import_3.bind)(cloneAllDimensionInfo, null, dimensions);
  return extSource;
}
function getRawData(upstream) {
  var sourceFormat = upstream.sourceFormat;
  if (!isSupportedSourceFormat(sourceFormat)) {
    var errMsg = '';
    if (false) {}
    (0,_util_log_js__rspack_import_2.throwError)(errMsg);
  }
  return upstream.data;
}
function cloneRawData(upstream) {
  var sourceFormat = upstream.sourceFormat;
  var data = upstream.data;
  if (!isSupportedSourceFormat(sourceFormat)) {
    var errMsg = '';
    if (false) {}
    (0,_util_log_js__rspack_import_2.throwError)(errMsg);
  }
  if (sourceFormat === _util_types_js__rspack_import_1.SOURCE_FORMAT_ARRAY_ROWS) {
    var result = [];
    for (var i = 0, len = data.length; i < len; i++) {
      // Not strictly clone for performance
      result.push(data[i].slice());
    }
    return result;
  } else if (sourceFormat === _util_types_js__rspack_import_1.SOURCE_FORMAT_OBJECT_ROWS) {
    var result = [];
    for (var i = 0, len = data.length; i < len; i++) {
      // Not strictly clone for performance
      result.push((0,zrender_lib_core_util_js__rspack_import_3.extend)({}, data[i]));
    }
    return result;
  }
}
function getDimensionInfo(dimensions, dimsByName, dim) {
  if (dim == null) {
    return;
  }
  // Keep the same logic as `List::getDimension` did.
  if ((0,zrender_lib_core_util_js__rspack_import_3.isNumber)(dim)
  // If being a number-like string but not being defined a dimension name.
  || !isNaN(dim) && !(0,zrender_lib_core_util_js__rspack_import_3.hasOwn)(dimsByName, dim)) {
    return dimensions[dim];
  } else if ((0,zrender_lib_core_util_js__rspack_import_3.hasOwn)(dimsByName, dim)) {
    return dimsByName[dim];
  }
}
function cloneAllDimensionInfo(dimensions) {
  return (0,zrender_lib_core_util_js__rspack_import_3.clone)(dimensions);
}
var externalTransformMap = (0,zrender_lib_core_util_js__rspack_import_3.createHashMap)();
function registerExternalTransform(externalTransform) {
  externalTransform = (0,zrender_lib_core_util_js__rspack_import_3.clone)(externalTransform);
  var type = externalTransform.type;
  var errMsg = '';
  if (!type) {
    if (false) {}
    (0,_util_log_js__rspack_import_2.throwError)(errMsg);
  }
  var typeParsed = type.split(':');
  if (typeParsed.length !== 2) {
    if (false) {}
    (0,_util_log_js__rspack_import_2.throwError)(errMsg);
  }
  // Namespace 'echarts:xxx' is official namespace, where the transforms should
  // be called directly via 'xxx' rather than 'echarts:xxx'.
  var isBuiltIn = false;
  if (typeParsed[0] === 'echarts') {
    type = typeParsed[1];
    isBuiltIn = true;
  }
  externalTransform.__isBuiltIn = isBuiltIn;
  externalTransformMap.set(type, externalTransform);
}
function applyDataTransform(rawTransOption, sourceList, infoForPrint) {
  var pipedTransOption = (0,_util_model_js__rspack_import_5.normalizeToArray)(rawTransOption);
  var pipeLen = pipedTransOption.length;
  var errMsg = '';
  if (!pipeLen) {
    if (false) {}
    (0,_util_log_js__rspack_import_2.throwError)(errMsg);
  }
  for (var i = 0, len = pipeLen; i < len; i++) {
    var transOption = pipedTransOption[i];
    sourceList = applySingleDataTransform(transOption, sourceList, infoForPrint, pipeLen === 1 ? null : i);
    // piped transform only support single input, except the fist one.
    // piped transform only support single output, except the last one.
    if (i !== len - 1) {
      sourceList.length = Math.max(sourceList.length, 1);
    }
  }
  return sourceList;
}
function applySingleDataTransform(transOption, upSourceList, infoForPrint,
// If `pipeIndex` is null/undefined, no piped transform.
pipeIndex) {
  var errMsg = '';
  if (!upSourceList.length) {
    if (false) {}
    (0,_util_log_js__rspack_import_2.throwError)(errMsg);
  }
  if (!(0,zrender_lib_core_util_js__rspack_import_3.isObject)(transOption)) {
    if (false) {}
    (0,_util_log_js__rspack_import_2.throwError)(errMsg);
  }
  var transType = transOption.type;
  var externalTransform = externalTransformMap.get(transType);
  if (!externalTransform) {
    if (false) {}
    (0,_util_log_js__rspack_import_2.throwError)(errMsg);
  }
  // Prepare source
  var extUpSourceList = (0,zrender_lib_core_util_js__rspack_import_3.map)(upSourceList, function (upSource) {
    return createExternalSource(upSource, externalTransform);
  });
  var resultList = (0,_util_model_js__rspack_import_5.normalizeToArray)(externalTransform.transform({
    upstream: extUpSourceList[0],
    upstreamList: extUpSourceList,
    config: (0,zrender_lib_core_util_js__rspack_import_3.clone)(transOption.config)
  }));
  if (false) { var printStrArr }
  return (0,zrender_lib_core_util_js__rspack_import_3.map)(resultList, function (result, resultIndex) {
    var errMsg = '';
    if (!(0,zrender_lib_core_util_js__rspack_import_3.isObject)(result)) {
      if (false) {}
      (0,_util_log_js__rspack_import_2.throwError)(errMsg);
    }
    if (!result.data) {
      if (false) {}
      (0,_util_log_js__rspack_import_2.throwError)(errMsg);
    }
    var sourceFormat = (0,_Source_js__rspack_import_6.detectSourceFormat)(result.data);
    if (!isSupportedSourceFormat(sourceFormat)) {
      if (false) {}
      (0,_util_log_js__rspack_import_2.throwError)(errMsg);
    }
    var resultMetaRawOption;
    var firstUpSource = upSourceList[0];
    /**
     * Intuitively, the end users known the content of the original `dataset.source`,
     * calucating the transform result in mind.
     * Suppose the original `dataset.source` is:
     * ```js
     * [
     *     ['product', '2012', '2013', '2014', '2015'],
     *     ['AAA', 41.1, 30.4, 65.1, 53.3],
     *     ['BBB', 86.5, 92.1, 85.7, 83.1],
     *     ['CCC', 24.1, 67.2, 79.5, 86.4]
     * ]
     * ```
     * The dimension info have to be detected from the source data.
     * Some of the transformers (like filter, sort) will follow the dimension info
     * of upstream, while others use new dimensions (like aggregate).
     * Transformer can output a field `dimensions` to define the its own output dimensions.
     * We also allow transformers to ignore the output `dimensions` field, and
     * inherit the upstream dimensions definition. It can reduce the burden of handling
     * dimensions in transformers.
     *
     * See also [DIMENSION_INHERIT_RULE] in `sourceManager.ts`.
     */
    if (firstUpSource && resultIndex === 0
    // If transformer returns `dimensions`, it means that the transformer has different
    // dimensions definitions. We do not inherit anything from upstream.
    && !result.dimensions) {
      var startIndex = firstUpSource.startIndex;
      // We copy the header of upstream to the result, because:
      // (1) The returned data always does not contain header line and can not be used
      // as dimension-detection. In this case we can not use "detected dimensions" of
      // upstream directly, because it might be detected based on different `seriesLayoutBy`.
      // (2) We should support that the series read the upstream source in `seriesLayoutBy: 'row'`.
      // So the original detected header should be add to the result, otherwise they can not be read.
      if (startIndex) {
        result.data = firstUpSource.data.slice(0, startIndex).concat(result.data);
      }
      resultMetaRawOption = {
        seriesLayoutBy: _util_types_js__rspack_import_1.SERIES_LAYOUT_BY_COLUMN,
        sourceHeader: startIndex,
        dimensions: firstUpSource.metaRawOption.dimensions
      };
    } else {
      resultMetaRawOption = {
        seriesLayoutBy: _util_types_js__rspack_import_1.SERIES_LAYOUT_BY_COLUMN,
        sourceHeader: 0,
        dimensions: result.dimensions
      };
    }
    return (0,_Source_js__rspack_import_6.createSource)(result.data, resultMetaRawOption, null);
  });
}
function isSupportedSourceFormat(sourceFormat) {
  return sourceFormat === _util_types_js__rspack_import_1.SOURCE_FORMAT_ARRAY_ROWS || sourceFormat === _util_types_js__rspack_import_1.SOURCE_FORMAT_OBJECT_ROWS;
}
__webpack_require__.d(__webpack_exports__, {
}, {
  ExternalSource: ExternalSource,
  applyDataTransform: applyDataTransform,
  registerExternalTransform: registerExternalTransform
});


}),
55296: (function (__unused_rspack___webpack_module__, __webpack_exports__, __webpack_require__) {
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Axis: function() { return /* reexport */ Axis["default"]; },
  ChartView: function() { return /* reexport */ Chart["default"]; },
  ComponentModel: function() { return /* reexport */ Component["default"]; },
  ComponentView: function() { return /* reexport */ view_Component["default"]; },
  List: function() { return /* reexport */ SeriesData["default"]; },
  Model: function() { return /* reexport */ model_Model["default"]; },
  PRIORITY: function() { return /* reexport */ echarts.PRIORITY; },
  SeriesModel: function() { return /* reexport */ Series["default"]; },
  color: function() { return /* reexport */ color; },
  connect: function() { return /* reexport */ echarts.connect; },
  dataTool: function() { return /* reexport */ echarts.dataTool; },
  dependencies: function() { return /* reexport */ echarts.dependencies; },
  disConnect: function() { return /* reexport */ echarts.disConnect; },
  disconnect: function() { return /* reexport */ echarts.disconnect; },
  dispose: function() { return /* reexport */ echarts.dispose; },
  env: function() { return /* reexport */ env["default"]; },
  extendChartView: function() { return /* reexport */ extendChartView; },
  extendComponentModel: function() { return /* reexport */ extendComponentModel; },
  extendComponentView: function() { return /* reexport */ extendComponentView; },
  extendSeriesModel: function() { return /* reexport */ extendSeriesModel; },
  format: function() { return /* reexport */ format_namespaceObject; },
  getCoordinateSystemDimensions: function() { return /* reexport */ echarts.getCoordinateSystemDimensions; },
  getInstanceByDom: function() { return /* reexport */ echarts.getInstanceByDom; },
  getInstanceById: function() { return /* reexport */ echarts.getInstanceById; },
  getMap: function() { return /* reexport */ echarts.getMap; },
  graphic: function() { return /* reexport */ graphic_namespaceObject; },
  helper: function() { return /* reexport */ helper_namespaceObject; },
  init: function() { return /* reexport */ echarts.init; },
  innerDrawElementOnCanvas: function() { return /* reexport */ canvas_graphic.brushSingle; },
  matrix: function() { return /* reexport */ matrix; },
  number: function() { return /* reexport */ number_namespaceObject; },
  parseGeoJSON: function() { return /* reexport */ parseGeoJson["default"]; },
  parseGeoJson: function() { return /* reexport */ parseGeoJson["default"]; },
  registerAction: function() { return /* reexport */ echarts.registerAction; },
  registerCoordinateSystem: function() { return /* reexport */ echarts.registerCoordinateSystem; },
  registerCustomSeries: function() { return /* reexport */ echarts.registerCustomSeries; },
  registerLayout: function() { return /* reexport */ echarts.registerLayout; },
  registerLoading: function() { return /* reexport */ echarts.registerLoading; },
  registerLocale: function() { return /* reexport */ echarts.registerLocale; },
  registerMap: function() { return /* reexport */ echarts.registerMap; },
  registerPostInit: function() { return /* reexport */ echarts.registerPostInit; },
  registerPostUpdate: function() { return /* reexport */ echarts.registerPostUpdate; },
  registerPreprocessor: function() { return /* reexport */ echarts.registerPreprocessor; },
  registerProcessor: function() { return /* reexport */ echarts.registerProcessor; },
  registerTheme: function() { return /* reexport */ echarts.registerTheme; },
  registerTransform: function() { return /* reexport */ echarts.registerTransform; },
  registerUpdateLifecycle: function() { return /* reexport */ echarts.registerUpdateLifecycle; },
  registerVisual: function() { return /* reexport */ echarts.registerVisual; },
  setCanvasCreator: function() { return /* reexport */ echarts.setCanvasCreator; },
  setPlatformAPI: function() { return /* reexport */ platform.setPlatformAPI; },
  throttle: function() { return /* reexport */ throttle.throttle; },
  time: function() { return /* reexport */ time_namespaceObject; },
  use: function() { return /* reexport */ extension.use; },
  util: function() { return /* reexport */ util_namespaceObject; },
  vector: function() { return /* reexport */ vector; },
  version: function() { return /* reexport */ echarts.version; },
  zrUtil: function() { return /* reexport */ util; },
  zrender: function() { return /* reexport */ zrender; }
});
// NAMESPACE OBJECT: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/export/api/helper.js
var helper_namespaceObject = {};
__webpack_require__.r(helper_namespaceObject);
__webpack_require__.d(helper_namespaceObject, { 
  createDimensions: function() { return createDimensions.createDimensions; },
  createList: function() { return createList; },
  createScale: function() { return createScale; },
  createSymbol: function() { return symbol.createSymbol; },
  createTextStyle: function() { return createTextStyle; },
  dataStack: function() { return dataStack; },
  enableHoverEmphasis: function() { return states.enableHoverEmphasis; },
  getECData: function() { return innerStore.getECData; },
  getLayoutRect: function() { return layout.getLayoutRect; },
  mixinAxisModelCommonMethods: function() { return mixinAxisModelCommonMethods; } });

// NAMESPACE OBJECT: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/export/api/number.js
var number_namespaceObject = {};
__webpack_require__.r(number_namespaceObject);
__webpack_require__.d(number_namespaceObject, { 
  MAX_SAFE_INTEGER: function() { return number.MAX_SAFE_INTEGER; },
  asc: function() { return number.asc; },
  getPercentWithPrecision: function() { return number.getPercentWithPrecision; },
  getPixelPrecision: function() { return number.getPixelPrecision; },
  getPrecision: function() { return number.getPrecision; },
  getPrecisionSafe: function() { return number.getPrecisionSafe; },
  isNumeric: function() { return number.isNumeric; },
  isRadianAroundZero: function() { return number.isRadianAroundZero; },
  linearMap: function() { return number.linearMap; },
  nice: function() { return number.nice; },
  numericToNumber: function() { return number.numericToNumber; },
  parseDate: function() { return number.parseDate; },
  parsePercent: function() { return number.parsePercent; },
  quantile: function() { return number.quantile; },
  quantity: function() { return number.quantity; },
  quantityExponent: function() { return number.quantityExponent; },
  reformIntervals: function() { return number.reformIntervals; },
  remRadian: function() { return number.remRadian; },
  round: function() { return number.roundLegacy; } });

// NAMESPACE OBJECT: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/export/api/time.js
var time_namespaceObject = {};
__webpack_require__.r(time_namespaceObject);
__webpack_require__.d(time_namespaceObject, { 
  format: function() { return time.format; },
  parse: function() { return number.parseDate; },
  roundTime: function() { return time.roundTime; } });

// NAMESPACE OBJECT: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/export/api/graphic.js
var graphic_namespaceObject = {};
__webpack_require__.r(graphic_namespaceObject);
__webpack_require__.d(graphic_namespaceObject, { 
  Arc: function() { return Arc["default"]; },
  BezierCurve: function() { return BezierCurve["default"]; },
  BoundingRect: function() { return BoundingRect["default"]; },
  Circle: function() { return Circle["default"]; },
  CompoundPath: function() { return CompoundPath["default"]; },
  Ellipse: function() { return Ellipse["default"]; },
  Group: function() { return Group["default"]; },
  Image: function() { return Image["default"]; },
  IncrementalDisplayable: function() { return IncrementalDisplayable["default"]; },
  Line: function() { return Line["default"]; },
  LinearGradient: function() { return LinearGradient["default"]; },
  Polygon: function() { return Polygon["default"]; },
  Polyline: function() { return Polyline["default"]; },
  RadialGradient: function() { return RadialGradient["default"]; },
  Rect: function() { return Rect["default"]; },
  Ring: function() { return Ring["default"]; },
  Sector: function() { return Sector["default"]; },
  Text: function() { return Text["default"]; },
  clipPointsByRect: function() { return graphic.clipPointsByRect; },
  clipRectByRect: function() { return graphic.clipRectByRect; },
  createIcon: function() { return graphic.createIcon; },
  extendPath: function() { return graphic.extendPath; },
  extendShape: function() { return graphic.extendShape; },
  getShapeClass: function() { return graphic.getShapeClass; },
  getTransform: function() { return graphic.getTransform; },
  initProps: function() { return basicTransition.initProps; },
  makeImage: function() { return graphic.makeImage; },
  makePath: function() { return graphic.makePath; },
  mergePath: function() { return graphic.mergePath; },
  registerShape: function() { return graphic.registerShape; },
  resizePath: function() { return graphic.resizePath; },
  updateProps: function() { return basicTransition.updateProps; } });

// NAMESPACE OBJECT: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/export/api/format.js
var format_namespaceObject = {};
__webpack_require__.r(format_namespaceObject);
__webpack_require__.d(format_namespaceObject, { 
  addCommas: function() { return format.addCommas; },
  capitalFirst: function() { return format.capitalFirst; },
  encodeHTML: function() { return dom.encodeHTML; },
  formatTime: function() { return format.formatTime; },
  formatTpl: function() { return format.formatTpl; },
  getTextRect: function() { return getTextRect.getTextRect; },
  getTooltipMarker: function() { return format.getTooltipMarker; },
  normalizeCssArray: function() { return format.normalizeCssArray; },
  toCamelCase: function() { return format.toCamelCase; },
  truncateText: function() { return parseText.truncateText; } });

// NAMESPACE OBJECT: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/export/api/util.js
var util_namespaceObject = {};
__webpack_require__.r(util_namespaceObject);
__webpack_require__.d(util_namespaceObject, { 
  bind: function() { return util.bind; },
  clone: function() { return util.clone; },
  curry: function() { return util.curry; },
  defaults: function() { return util.defaults; },
  each: function() { return util.each; },
  extend: function() { return util.extend; },
  filter: function() { return util.filter; },
  indexOf: function() { return util.indexOf; },
  inherits: function() { return util.inherits; },
  isArray: function() { return util.isArray; },
  isFunction: function() { return util.isFunction; },
  isObject: function() { return util.isObject; },
  isString: function() { return util.isString; },
  map: function() { return util.map; },
  merge: function() { return util.merge; },
  reduce: function() { return util.reduce; } });


// EXTERNAL MODULE: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/core/echarts.js + 2 modules
var echarts = __webpack_require__(88251);
// EXTERNAL MODULE: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/model/Component.js
var Component = __webpack_require__(23074);
// EXTERNAL MODULE: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/view/Component.js
var view_Component = __webpack_require__(80734);
// EXTERNAL MODULE: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/model/Series.js
var Series = __webpack_require__(80424);
// EXTERNAL MODULE: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/view/Chart.js
var Chart = __webpack_require__(3861);
// EXTERNAL MODULE: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/data/SeriesData.js
var SeriesData = __webpack_require__(24179);
// EXTERNAL MODULE: ./node_modules/.pnpm/zrender@6.1.0/node_modules/zrender/lib/zrender.js
var zrender = __webpack_require__(82653);
// EXTERNAL MODULE: ./node_modules/.pnpm/zrender@6.1.0/node_modules/zrender/lib/core/matrix.js
var matrix = __webpack_require__(51938);
// EXTERNAL MODULE: ./node_modules/.pnpm/zrender@6.1.0/node_modules/zrender/lib/core/vector.js
var vector = __webpack_require__(69884);
// EXTERNAL MODULE: ./node_modules/.pnpm/zrender@6.1.0/node_modules/zrender/lib/core/util.js
var util = __webpack_require__(75275);
// EXTERNAL MODULE: ./node_modules/.pnpm/zrender@6.1.0/node_modules/zrender/lib/tool/color.js
var color = __webpack_require__(47881);
// EXTERNAL MODULE: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/util/throttle.js
var throttle = __webpack_require__(88790);
// EXTERNAL MODULE: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/chart/helper/createSeriesData.js
var createSeriesData = __webpack_require__(16916);
// EXTERNAL MODULE: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/coord/axisHelper.js
var axisHelper = __webpack_require__(72460);
// EXTERNAL MODULE: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/coord/axisModelCommonMixin.js
var axisModelCommonMixin = __webpack_require__(59417);
// EXTERNAL MODULE: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/model/Model.js + 2 modules
var model_Model = __webpack_require__(98899);
// EXTERNAL MODULE: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/util/layout.js
var layout = __webpack_require__(29268);
// EXTERNAL MODULE: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/data/helper/dataStackHelper.js
var dataStackHelper = __webpack_require__(58337);
// EXTERNAL MODULE: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/util/innerStore.js
var innerStore = __webpack_require__(63655);
// EXTERNAL MODULE: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/label/labelStyle.js
var labelStyle = __webpack_require__(47135);
// EXTERNAL MODULE: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/coord/axisNiceTicks.js
var axisNiceTicks = __webpack_require__(85931);
// EXTERNAL MODULE: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/data/helper/createDimensions.js
var createDimensions = __webpack_require__(31292);
// EXTERNAL MODULE: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/util/symbol.js
var symbol = __webpack_require__(87914);
// EXTERNAL MODULE: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/util/states.js
var states = __webpack_require__(71900);
;// CONCATENATED MODULE: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/export/api/helper.js

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/


/**
 * AUTO-GENERATED FILE. DO NOT MODIFY.
 */

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/
/**
 * This module exposes helper functions for developing extensions.
 */


// import createGraphFromNodeEdge from './chart/helper/createGraphFromNodeEdge.js';








/**
 * Create a multi dimension List structure from seriesModel.
 */
function createList(seriesModel) {
  return (0,createSeriesData["default"])(null, seriesModel);
}
// export function createGraph(seriesModel) {
//     let nodes = seriesModel.get('data');
//     let links = seriesModel.get('links');
//     return createGraphFromNodeEdge(nodes, links, seriesModel);
// }


var dataStack = {
  isDimensionStacked: dataStackHelper.isDimensionStacked,
  enableDataStack: dataStackHelper.enableDataStack,
  getStackedDimension: dataStackHelper.getStackedDimension
};
/**
 * Create a symbol element with given symbol configuration: shape, x, y, width, height, color
 * @param {string} symbolDesc
 * @param {number} x
 * @param {number} y
 * @param {number} w
 * @param {number} h
 * @param {string} color
 */

/**
 * Externally used by echarts-gl.
 * Create scale
 * @param dataExtent
 * @param option If `option.type`
 *        is specified, it can only be `'value'` currently.
 */
function createScale(dataExtent, option) {
  var axisModel = option;
  if (!(option instanceof model_Model["default"])) {
    axisModel = new model_Model["default"](option);
    // FIXME
    // Currently AxisModelCommonMixin has nothing to do with the
    // the requirements of `axisHelper.createScaleByModel`. For
    // example the methods `getCategories` and `getOrdinalMeta`
    // are required for `'category'` axis, and ecModel is required
    // for `'time'` axis. But occasionally echarts-gl happened
    // to only use `'value'` axis.
    // zrUtil.mixin(axisModel, AxisModelCommonMixin);
  }
  var axisType = axisHelper.determineAxisType(axisModel);
  var scale = axisHelper.createScaleByModel(axisModel, axisType, false);
  if (dataExtent[1] < dataExtent[0]) {
    dataExtent = dataExtent.slice().reverse();
  }
  (0,axisNiceTicks.scaleCalcNice2)(scale, axisModel, null, null, dataExtent);
  return scale;
}
/**
 * Mixin common methods to axis model
 */
function mixinAxisModelCommonMethods(Model) {
  util.mixin(Model, axisModelCommonMixin.AxisModelCommonMixin);
}


function createTextStyle(textStyleModel, opts) {
  opts = opts || {};
  return (0,labelStyle.createTextStyle)(textStyleModel, null, null, opts.state !== 'normal');
}
// EXTERNAL MODULE: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/extension.js
var extension = __webpack_require__(69210);
// EXTERNAL MODULE: ./node_modules/.pnpm/zrender@6.1.0/node_modules/zrender/lib/core/platform.js
var platform = __webpack_require__(77592);
// EXTERNAL MODULE: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/coord/geo/parseGeoJson.js
var parseGeoJson = __webpack_require__(72957);
// EXTERNAL MODULE: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/util/number.js
var number = __webpack_require__(46823);
;// CONCATENATED MODULE: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/export/api/number.js

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/


/**
 * AUTO-GENERATED FILE. DO NOT MODIFY.
 */

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/

// EXTERNAL MODULE: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/util/time.js
var time = __webpack_require__(80155);
;// CONCATENATED MODULE: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/export/api/time.js

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/


/**
 * AUTO-GENERATED FILE. DO NOT MODIFY.
 */

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/


// EXTERNAL MODULE: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/util/graphic.js
var graphic = __webpack_require__(90088);
// EXTERNAL MODULE: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/animation/basicTransition.js
var basicTransition = __webpack_require__(13983);
// EXTERNAL MODULE: ./node_modules/.pnpm/zrender@6.1.0/node_modules/zrender/lib/graphic/Group.js
var Group = __webpack_require__(80111);
// EXTERNAL MODULE: ./node_modules/.pnpm/zrender@6.1.0/node_modules/zrender/lib/graphic/Image.js
var Image = __webpack_require__(9529);
// EXTERNAL MODULE: ./node_modules/.pnpm/zrender@6.1.0/node_modules/zrender/lib/graphic/Text.js
var Text = __webpack_require__(24261);
// EXTERNAL MODULE: ./node_modules/.pnpm/zrender@6.1.0/node_modules/zrender/lib/graphic/shape/Circle.js
var Circle = __webpack_require__(34788);
// EXTERNAL MODULE: ./node_modules/.pnpm/zrender@6.1.0/node_modules/zrender/lib/graphic/shape/Ellipse.js
var Ellipse = __webpack_require__(71264);
// EXTERNAL MODULE: ./node_modules/.pnpm/zrender@6.1.0/node_modules/zrender/lib/graphic/shape/Sector.js + 1 modules
var Sector = __webpack_require__(72247);
// EXTERNAL MODULE: ./node_modules/.pnpm/zrender@6.1.0/node_modules/zrender/lib/graphic/shape/Ring.js
var Ring = __webpack_require__(65274);
// EXTERNAL MODULE: ./node_modules/.pnpm/zrender@6.1.0/node_modules/zrender/lib/graphic/shape/Polygon.js
var Polygon = __webpack_require__(98028);
// EXTERNAL MODULE: ./node_modules/.pnpm/zrender@6.1.0/node_modules/zrender/lib/graphic/shape/Polyline.js
var Polyline = __webpack_require__(89116);
// EXTERNAL MODULE: ./node_modules/.pnpm/zrender@6.1.0/node_modules/zrender/lib/graphic/shape/Rect.js + 1 modules
var Rect = __webpack_require__(67485);
// EXTERNAL MODULE: ./node_modules/.pnpm/zrender@6.1.0/node_modules/zrender/lib/graphic/shape/Line.js
var Line = __webpack_require__(70582);
// EXTERNAL MODULE: ./node_modules/.pnpm/zrender@6.1.0/node_modules/zrender/lib/graphic/shape/BezierCurve.js
var BezierCurve = __webpack_require__(63316);
// EXTERNAL MODULE: ./node_modules/.pnpm/zrender@6.1.0/node_modules/zrender/lib/graphic/shape/Arc.js
var Arc = __webpack_require__(52994);
// EXTERNAL MODULE: ./node_modules/.pnpm/zrender@6.1.0/node_modules/zrender/lib/graphic/IncrementalDisplayable.js
var IncrementalDisplayable = __webpack_require__(73240);
// EXTERNAL MODULE: ./node_modules/.pnpm/zrender@6.1.0/node_modules/zrender/lib/graphic/CompoundPath.js
var CompoundPath = __webpack_require__(8556);
// EXTERNAL MODULE: ./node_modules/.pnpm/zrender@6.1.0/node_modules/zrender/lib/graphic/LinearGradient.js
var LinearGradient = __webpack_require__(44315);
// EXTERNAL MODULE: ./node_modules/.pnpm/zrender@6.1.0/node_modules/zrender/lib/graphic/RadialGradient.js
var RadialGradient = __webpack_require__(61929);
// EXTERNAL MODULE: ./node_modules/.pnpm/zrender@6.1.0/node_modules/zrender/lib/core/BoundingRect.js
var BoundingRect = __webpack_require__(93689);
;// CONCATENATED MODULE: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/export/api/graphic.js

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/


/**
 * AUTO-GENERATED FILE. DO NOT MODIFY.
 */

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/

// EXTERNAL MODULE: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/util/format.js
var format = __webpack_require__(13501);
// EXTERNAL MODULE: ./node_modules/.pnpm/zrender@6.1.0/node_modules/zrender/lib/core/dom.js + 1 modules
var dom = __webpack_require__(84563);
// EXTERNAL MODULE: ./node_modules/.pnpm/zrender@6.1.0/node_modules/zrender/lib/graphic/helper/parseText.js
var parseText = __webpack_require__(83673);
// EXTERNAL MODULE: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/legacy/getTextRect.js
var getTextRect = __webpack_require__(17658);
;// CONCATENATED MODULE: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/export/api/format.js

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/


/**
 * AUTO-GENERATED FILE. DO NOT MODIFY.
 */

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/

;// CONCATENATED MODULE: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/export/api/util.js

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/


/**
 * AUTO-GENERATED FILE. DO NOT MODIFY.
 */

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/

// EXTERNAL MODULE: ./node_modules/.pnpm/zrender@6.1.0/node_modules/zrender/lib/core/env.js
var env = __webpack_require__(26444);
// EXTERNAL MODULE: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/coord/Axis.js
var Axis = __webpack_require__(70808);
// EXTERNAL MODULE: ./node_modules/.pnpm/zrender@6.1.0/node_modules/zrender/lib/canvas/graphic.js
var canvas_graphic = __webpack_require__(41548);
;// CONCATENATED MODULE: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/export/api.js

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/


/**
 * AUTO-GENERATED FILE. DO NOT MODIFY.
 */

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/
// These APIs are for more advanced usages
// For example extend charts and components, creating graphic elements, formatting.




















// --------------------- Helper Methods ---------------------













// --------------------- Export for Extension Usage ---------------------
// export {SeriesData};
 // TODO: Compatitable with exists echarts-gl code



// Only for GL

// --------------------- Deprecated Extension Methods ---------------------
// Should use `ComponentModel.extend` or `class XXXX extend ComponentModel` to create class.
// Then use `registerComponentModel` in `install` parameter when `use` this extension. For example:
// class Bar3DModel extends ComponentModel {}
// export function install(registers) { registers.registerComponentModel(Bar3DModel); }
// echarts.use(install);
function extendComponentModel(proto) {
  var Model = Component["default"].extend(proto);
  Component["default"].registerClass(Model);
  return Model;
}
function extendComponentView(proto) {
  var View = view_Component["default"].extend(proto);
  view_Component["default"].registerClass(View);
  return View;
}
function extendSeriesModel(proto) {
  var Model = Series["default"].extend(proto);
  Series["default"].registerClass(Model);
  return Model;
}
function extendChartView(proto) {
  var View = Chart["default"].extend(proto);
  Chart["default"].registerClass(View);
  return View;
}
// EXTERNAL MODULE: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/label/installLabelLayout.js + 1 modules
var installLabelLayout = __webpack_require__(27046);
;// CONCATENATED MODULE: ./node_modules/.pnpm/echarts@6.1.0/node_modules/echarts/lib/export/core.js

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/


/**
 * AUTO-GENERATED FILE. DO NOT MODIFY.
 */

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/
// Core API from echarts/src/echarts



// Import label layout by default.
// TODO will be treeshaked.

(0,extension.use)(installLabelLayout.installLabelLayout);

}),
69210: (function (__unused_rspack___webpack_module__, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
/* import */ var _core_echarts_js__rspack_import_0 = __webpack_require__(88251);
/* import */ var _view_Component_js__rspack_import_3 = __webpack_require__(80734);
/* import */ var _view_Chart_js__rspack_import_5 = __webpack_require__(3861);
/* import */ var _model_Component_js__rspack_import_2 = __webpack_require__(23074);
/* import */ var _model_Series_js__rspack_import_4 = __webpack_require__(80424);
/* import */ var zrender_lib_core_util_js__rspack_import_8 = __webpack_require__(75275);
/* import */ var _core_impl_js__rspack_import_1 = __webpack_require__(98229);
/* import */ var zrender_lib_zrender_js__rspack_import_7 = __webpack_require__(82653);
/* import */ var _chart_custom_customSeriesRegister_js__rspack_import_6 = __webpack_require__(7987);

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/


/**
 * AUTO-GENERATED FILE. DO NOT MODIFY.
 */

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/









var extensions = [];
var extensionRegisters = {
  registerPreprocessor: _core_echarts_js__rspack_import_0.registerPreprocessor,
  registerProcessor: _core_echarts_js__rspack_import_0.registerProcessor,
  registerPostInit: _core_echarts_js__rspack_import_0.registerPostInit,
  registerPostUpdate: _core_echarts_js__rspack_import_0.registerPostUpdate,
  registerUpdateLifecycle: _core_echarts_js__rspack_import_0.registerUpdateLifecycle,
  registerAction: _core_echarts_js__rspack_import_0.registerAction,
  registerCoordinateSystem: _core_echarts_js__rspack_import_0.registerCoordinateSystem,
  registerLayout: _core_echarts_js__rspack_import_0.registerLayout,
  registerVisual: _core_echarts_js__rspack_import_0.registerVisual,
  registerTransform: _core_echarts_js__rspack_import_0.registerTransform,
  registerLoading: _core_echarts_js__rspack_import_0.registerLoading,
  registerMap: _core_echarts_js__rspack_import_0.registerMap,
  registerImpl: _core_impl_js__rspack_import_1.registerImpl,
  PRIORITY: _core_echarts_js__rspack_import_0.PRIORITY,
  ComponentModel: _model_Component_js__rspack_import_2["default"],
  ComponentView: _view_Component_js__rspack_import_3["default"],
  SeriesModel: _model_Series_js__rspack_import_4["default"],
  ChartView: _view_Chart_js__rspack_import_5["default"],
  // TODO Use ComponentModel and SeriesModel instead of Constructor
  registerComponentModel: function (ComponentModelClass) {
    _model_Component_js__rspack_import_2["default"].registerClass(ComponentModelClass);
  },
  registerComponentView: function (ComponentViewClass) {
    _view_Component_js__rspack_import_3["default"].registerClass(ComponentViewClass);
  },
  registerSeriesModel: function (SeriesModelClass) {
    _model_Series_js__rspack_import_4["default"].registerClass(SeriesModelClass);
  },
  registerChartView: function (ChartViewClass) {
    _view_Chart_js__rspack_import_5["default"].registerClass(ChartViewClass);
  },
  registerCustomSeries: function (seriesType, renderItem) {
    (0,_chart_custom_customSeriesRegister_js__rspack_import_6.registerCustomSeries)(seriesType, renderItem);
  },
  registerSubTypeDefaulter: function (componentType, defaulter) {
    _model_Component_js__rspack_import_2["default"].registerSubTypeDefaulter(componentType, defaulter);
  },
  registerPainter: function (painterType, PainterCtor) {
    (0,zrender_lib_zrender_js__rspack_import_7.registerPainter)(painterType, PainterCtor);
  }
};
function use(ext) {
  if ((0,zrender_lib_core_util_js__rspack_import_8.isArray)(ext)) {
    // use([ChartLine, ChartBar]);
    (0,zrender_lib_core_util_js__rspack_import_8.each)(ext, function (singleExt) {
      use(singleExt);
    });
    return;
  }
  if ((0,zrender_lib_core_util_js__rspack_import_8.indexOf)(extensions, ext) >= 0) {
    return;
  }
  extensions.push(ext);
  if ((0,zrender_lib_core_util_js__rspack_import_8.isFunction)(ext)) {
    ext = {
      install: ext
    };
  }
  ext.install(extensionRegisters);
}
__webpack_require__.d(__webpack_exports__, {
}, {
  use: use
});


}),
75797: (function (__unused_rspack___webpack_module__, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/


/**
 * AUTO-GENERATED FILE. DO NOT MODIFY.
 */

/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
/**
 * Language: English.
 */
/* export default */ __webpack_exports__["default"] = ({
  time: {
    month: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
    monthAbbr: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    dayOfWeek: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
    dayOfWeekAbbr: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
  },
  legend: {
    selector: {
      all: 'All',
      inverse: 'Inv'
    }
  },
  toolbox: {
    brush: {
      title: {
        rect: 'Box Select',
        polygon: 'Lasso Select',
        lineX: 'Horizontally Select',
        lineY: 'Vertically Select',
        keep: 'Keep Selections',
        clear: 'Clear Selections'
      }
    },
    dataView: {
      title: 'Data View',
      lang: ['Data View', 'Close', 'Refresh']
    },
    dataZoom: {
      title: {
        zoom: 'Zoom',
        back: 'Zoom Reset'
      }
    },
    magicType: {
      title: {
        line: 'Switch to Line Chart',
        bar: 'Switch to Bar Chart',
        stack: 'Stack',
        tiled: 'Tile'
      }
    },
    restore: {
      title: 'Restore'
    },
    saveAsImage: {
      title: 'Save as Image',
      lang: ['Right Click to Save Image']
    }
  },
  series: {
    typeNames: {
      pie: 'Pie chart',
      bar: 'Bar chart',
      line: 'Line chart',
      scatter: 'Scatter plot',
      effectScatter: 'Ripple scatter plot',
      radar: 'Radar chart',
      tree: 'Tree',
      treemap: 'Treemap',
      boxplot: 'Boxplot',
      candlestick: 'Candlestick',
      k: 'K line chart',
      heatmap: 'Heat map',
      map: 'Map',
      parallel: 'Parallel coordinate map',
      lines: 'Line graph',
      graph: 'Relationship graph',
      sankey: 'Sankey diagram',
      funnel: 'Funnel chart',
      gauge: 'Gauge',
      pictorialBar: 'Pictorial bar',
      themeRiver: 'Theme River Map',
      sunburst: 'Sunburst',
      custom: 'Custom chart',
      chart: 'Chart'
    }
  },
  aria: {
    general: {
      withTitle: 'This is a chart about "{title}"',
      withoutTitle: 'This is a chart'
    },
    series: {
      single: {
        prefix: '',
        withName: ' with type {seriesType} named {seriesName}.',
        withoutName: ' with type {seriesType}.'
      },
      multiple: {
        prefix: '. It consists of {seriesCount} series count.',
        withName: ' The {seriesId} series is a {seriesType} representing {seriesName}.',
        withoutName: ' The {seriesId} series is a {seriesType}.',
        separator: {
          middle: '',
          end: ''
        }
      }
    },
    data: {
      allData: 'The data is as follows: ',
      partialData: 'The first {displayCnt} items are: ',
      withName: 'the data for {name} is {value}',
      withoutName: '{value}',
      separator: {
        middle: ', ',
        end: '. '
      }
    }
  }
});

}),
75828: (function (__unused_rspack___webpack_module__, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
*/


/**
 * AUTO-GENERATED FILE. DO NOT MODIFY.
 */

/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
/* export default */ __webpack_exports__["default"] = ({
  time: {
    month: ['一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月', '十二月'],
    monthAbbr: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
    dayOfWeek: ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'],
    dayOfWeekAbbr: ['日', '一', '二', '三', '四', '五', '六']
  },
  legend: {
    selector: {
      all: '全选',
      inverse: '反选'
    }
  },
  toolbox: {
    brush: {
      title: {
        rect: '矩形选择',
        polygon: '圈选',
        lineX: '横向选择',
        lineY: '纵向选择',
        keep: '保持选择',
        clear: '清除选择'
      }
    },
    dataView: {
      title: '数据视图',
      lang: ['数据视图', '关闭', '刷新']
    },
    dataZoom: {
      title: {
        zoom: '区域缩放',
        back: '区域缩放还原'
      }
    },
    magicType: {
      title: {
        line: '切换为折线图',
        bar: '切换为柱状图',
        stack: '切换为堆叠',
        tiled: '切换为平铺'
      }
    },
    restore: {
      title: '还原'
    },
    saveAsImage: {
      title: '保存为图片',
      lang: ['右键另存为图片']
    }
  },
  series: {
    typeNames: {
      pie: '饼图',
      bar: '柱状图',
      line: '折线图',
      scatter: '散点图',
      effectScatter: '涟漪散点图',
      radar: '雷达图',
      tree: '树图',
      treemap: '矩形树图',
      boxplot: '箱型图',
      candlestick: 'K线图',
      k: 'K线图',
      heatmap: '热力图',
      map: '地图',
      parallel: '平行坐标图',
      lines: '线图',
      graph: '关系图',
      sankey: '桑基图',
      funnel: '漏斗图',
      gauge: '仪表盘图',
      pictorialBar: '象形柱图',
      themeRiver: '主题河流图',
      sunburst: '旭日图',
      custom: '自定义图表',
      chart: '图表'
    }
  },
  aria: {
    general: {
      withTitle: '这是一个关于“{title}”的图表。',
      withoutTitle: '这是一个图表，'
    },
    series: {
      single: {
        prefix: '',
        withName: '图表类型是{seriesType}，表示{seriesName}。',
        withoutName: '图表类型是{seriesType}。'
      },
      multiple: {
        prefix: '它由{seriesCount}个图表系列组成。',
        withName: '第{seriesId}个系列是一个表示{seriesName}的{seriesType}，',
        withoutName: '第{seriesId}个系列是一个{seriesType}，',
        separator: {
          middle: '；',
          end: '。'
        }
      }
    },
    data: {
      allData: '其数据是——',
      partialData: '其中，前{displayCnt}项是——',
      withName: '{name}的数据是{value}',
      withoutName: '{value}',
      separator: {
        middle: '，',
        end: ''
      }
    }
  }
});

}),

}]);